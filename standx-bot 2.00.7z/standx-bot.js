require('dotenv').config();
const { ethers } = require('ethers');
const axios = require('axios');
const crypto = require('crypto');
const { HttpsProxyAgent } = require('https-proxy-agent');
const https = require('https');
const WebSocket = require('ws');
const EventEmitter = require('events');
const readline = require('readline');
const STRATEGY_CONFIG = {
    aggressive: {
        spreadBps: 9,             // 100%积分：开单距离9bps，保持8-10
        spreadBpsMax: 9.8,
        maxBpsDrift: 9.8,
        dangerBps: 3,
        volatilityThreshold: 15,
        volatilityDelay: 30000,
        pointsMultiplier: 1.0,
        minBpsForRange: 0,
        maxBpsForRange: 10,
    },
    conservative: {
        spreadBps: 20,            // 50%积分：开单距离20bps，保持10-30
        spreadBpsMax: 28,
        maxBpsDrift: 28,
        dangerBps: 10,            // 10bps撤单
        volatilityThreshold: 50,
        volatilityDelay: 120000,
        pointsMultiplier: 0.5,
        minBpsForRange: 10,
        maxBpsForRange: 30,
    },
    common: {
        maxEffectiveQtyPerSide: 2,
        targetUptimePercent: 70,
        minUptimePercent: 50,
        minOrderDuration: 3000,
        refreshInterval: 30000,
        priceChangeThreshold: 0.0003,
        marginRatio: 0.99,            // 提高到99%，最大化资金利用率（挂单不成交）
        targetLeverage: 40,
        maxLoss: 5,
        consecutiveFillsThreshold: 1,
        rsiOversold: 30,
        rsiOverbought: 70,
    }
};
const colors = {
    reset: '\x1b[0m',
    red: '\x1b[31m',
    green: '\x1b[32m',
    yellow: '\x1b[33m',
    cyan: '\x1b[36m',
    blue: '\x1b[34m',
    magenta: '\x1b[35m'
};
function normalizeProxyUrl(proxyUrl) {
    if (!proxyUrl || proxyUrl.trim() === '') {
        return null;
    }
    proxyUrl = proxyUrl.trim();
    if (proxyUrl.includes('://')) {
        return proxyUrl;
    }
    const parts = proxyUrl.split(':');
    if (parts.length === 4) {
        const [host, port, username, password] = parts;
        return `http://${username}:${password}@${host}:${port}`;
    } else if (parts.length === 2) {
        const [host, port] = parts;
        return `http://${host}:${port}`;
    } else {
        console.warn(`⚠️  无法识别的代理格式: ${proxyUrl}`);
        return proxyUrl;
    }
}
function maskProxyUrl(proxyUrl) {
    if (!proxyUrl) return '';
    if (proxyUrl.includes('://')) {
        return proxyUrl.replace(/\/\/.*:.*@/, '//***:***@').replace(/:(\d+):.*:.*$/, ':$1:***:***');
    }
    return proxyUrl;
}
function smoothedAverage(data, period) {
    if (data.length < period) {
        return [];
    }
    const result = [];
    let sum = 0;
    for (let i = 0; i < period; i++) {
        sum += data[i];
    }
    result.push(sum / period);
    for (let i = period; i < data.length; i++) {
        const smoothed = (result[result.length - 1] * (period - 1) + data[i]) / period;
        result.push(smoothed);
    }
    return result;
}
async function fetchRSI(symbol, interval = '5m', period = 14) {
    try {
        const binanceSymbol = symbol.replace('-', '').replace('USD', 'USDT');
        const response = await axios.get('https://api.binance.com/api/v3/klines', {
            params: {
                symbol: binanceSymbol,
                interval: interval,
                limit: period + 10
            },
            timeout: 5000
        });
        if (!response.data || response.data.length < period + 1) {
            return null;
        }
        const closes = response.data.map(k => parseFloat(k[4]));
        const gains = [];
        const losses = [];
        for (let i = 1; i < closes.length; i++) {
            const change = closes[i] - closes[i - 1];
            gains.push(change > 0 ? change : 0);
            losses.push(change < 0 ? Math.abs(change) : 0);
        }
        const avgGain = gains.slice(-period).reduce((a, b) => a + b, 0) / period;
        const avgLoss = losses.slice(-period).reduce((a, b) => a + b, 0) / period;
        if (avgLoss === 0) return 100;
        const rs = avgGain / avgLoss;
        const rsi = 100 - (100 / (1 + rs));
        return rsi;
    } catch (e) {
        return null;
    }
}
async function fetchADX(symbol, interval = '5m', period = 14) {
    try {
        const binanceSymbol = symbol.replace('-', '').replace('USD', 'USDT');
        const response = await axios.get('https://api.binance.com/api/v3/klines', {
            params: {
                symbol: binanceSymbol,
                interval: interval,
                limit: 100
            },
            timeout: 5000
        });
        if (!response.data || response.data.length < period + 1) {
            return null;
        }
        const klines = response.data;
        const highs = klines.map(k => parseFloat(k[2]));
        const lows = klines.map(k => parseFloat(k[3]));
        const closes = klines.map(k => parseFloat(k[4]));
        const tr = [];
        const plusDM = [];
        const minusDM = [];
        for (let i = 1; i < klines.length; i++) {
            const high = highs[i];
            const low = lows[i];
            const prevHigh = highs[i - 1];
            const prevLow = lows[i - 1];
            const prevClose = closes[i - 1];
            const trValue = Math.max(
                high - low,
                Math.abs(high - prevClose),
                Math.abs(low - prevClose)
            );
            tr.push(trValue);
            const upMove = high - prevHigh;
            const downMove = prevLow - low;
            if (upMove > downMove && upMove > 0) {
                plusDM.push(upMove);
            } else {
                plusDM.push(0);
            }
            if (downMove > upMove && downMove > 0) {
                minusDM.push(downMove);
            } else {
                minusDM.push(0);
            }
        }
        const smoothedTR = smoothedAverage(tr, period);
        const smoothedPlusDM = smoothedAverage(plusDM, period);
        const smoothedMinusDM = smoothedAverage(minusDM, period);
        const plusDI = [];
        const minusDI = [];
        for (let i = 0; i < smoothedTR.length; i++) {
            if (smoothedTR[i] > 0) {
                plusDI.push((smoothedPlusDM[i] / smoothedTR[i]) * 100);
                minusDI.push((smoothedMinusDM[i] / smoothedTR[i]) * 100);
            } else {
                plusDI.push(0);
                minusDI.push(0);
            }
        }
        const dx = [];
        for (let i = 0; i < plusDI.length; i++) {
            const sum = plusDI[i] + minusDI[i];
            if (sum > 0) {
                dx.push(Math.abs(plusDI[i] - minusDI[i]) / sum * 100);
            } else {
                dx.push(0);
            }
        }
        if (dx.length < period) {
            return null;
        }
        const adx = smoothedAverage(dx, period);
        return adx.length > 0 ? adx[adx.length - 1] : null;
    } catch (e) {
        return null;
    }
}
async function selectStrategyMode() {
    if (process.env.STRATEGY_MODE) {
        const modeEnv = process.env.STRATEGY_MODE;
        const modeConfig = modeEnv === 'conservative'
            ? STRATEGY_CONFIG.conservative
            : STRATEGY_CONFIG.aggressive;
        return {
            mode: modeEnv,
            grid: process.env.GRID_ENABLED === 'true',
            gridCount: parseInt(process.env.GRID_COUNT || '10'),
            spreadBps: parseFloat(process.env.SPREAD_BPS || modeConfig.spreadBps),
            spreadBpsMax: parseFloat(process.env.SPREAD_BPS_MAX || modeConfig.spreadBpsMax),
            maxBpsDrift: parseFloat(process.env.MAX_BPS_DRIFT || modeConfig.maxBpsDrift)
        };
    }
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });
    console.log('📊 第一步：选择策略类型\n');
    console.log(`${colors.cyan}1️⃣  单档模式 (传统)${colors.reset}`);
    console.log('   ├─ 买卖各挂 1 单');
    console.log('   └─ 简单直接\n');
    console.log(`${colors.green}2️⃣  网格模式 (推荐)${colors.reset}`);
    console.log('   ├─ 买卖各挂多单');
    console.log('   └─ 分散风险，更稳定\n');
    const strategyType = await new Promise((resolve) => {
        rl.question('请选择 [1/2] (默认: 2): ', (answer) => {
            const choice = answer.trim() || '2';
            if (choice === '1') {
                console.log(`\n${colors.cyan}✅ 已选择: 单档模式${colors.reset}\n`);
                resolve('single');
            } else {
                console.log(`\n${colors.green}✅ 已选择: 网格模式 (档数根据余额自动调整)${colors.reset}\n`);
                resolve('grid');
            }
        });
    });
    const gridCount = 10;
    console.log('📊 第二步：选择积分档位\n');
    console.log(`${colors.red}1️⃣  网格100 (0-10 bps = 100% 积分)${colors.reset}`);
    console.log(`   ├─ 网格范围: ${STRATEGY_CONFIG.aggressive.spreadBps}-${STRATEGY_CONFIG.aggressive.spreadBpsMax} bps`);
    console.log('   ├─ 积分效率: 100% (最高档)');
    console.log('   ├─ Maker Uptime: ✅ 可获得 (双边≤10bps)');
    console.log(`   ├─ Uptime要求: ${STRATEGY_CONFIG.common.targetUptimePercent}%+时间 = 1.0x乘数`);
    console.log(`   ├─ 每边上限: ${STRATEGY_CONFIG.common.maxEffectiveQtyPerSide} BTC`);
    console.log('   └─ 适合: 追求最大收益，价格波动较小\n');
    console.log(`${colors.green}2️⃣  网格50 (10-30 bps = 50% 积分)${colors.reset}`);
    console.log(`   ├─ 网格范围: ${STRATEGY_CONFIG.conservative.spreadBps}-${STRATEGY_CONFIG.conservative.spreadBpsMax} bps`);
    console.log('   ├─ 积分效率: 50%');
    console.log('   ├─ 成交风险: 极低');
    console.log('   ├─ Maker Uptime: ❌ 不计入 (需≤10bps)');
    console.log('   └─ 适合: 价格剧烈波动时\n');
    return new Promise((resolve) => {
        rl.question('请选择 [1/2] (默认: 1): ', (answer) => {
            rl.close();
            const choice = answer.trim() || '1';
            let mode;
            let spreadBps;
            let spreadBpsMax;
            let maxBpsDrift;
            if (choice === '1') {
                console.log(`\n${colors.red}✅ 已选择: 网格100 (100% 积分 + Maker Uptime)${colors.reset}\n`);
                mode = 'aggressive';
                spreadBps = STRATEGY_CONFIG.aggressive.spreadBps;
                spreadBpsMax = STRATEGY_CONFIG.aggressive.spreadBpsMax;
                maxBpsDrift = STRATEGY_CONFIG.aggressive.maxBpsDrift;
            } else {
                console.log(`\n${colors.green}✅ 已选择: 网格50 (50% 积分)${colors.reset}\n`);
                mode = 'conservative';
                spreadBps = STRATEGY_CONFIG.conservative.spreadBps;
                spreadBpsMax = STRATEGY_CONFIG.conservative.spreadBpsMax;
                maxBpsDrift = STRATEGY_CONFIG.conservative.maxBpsDrift;
            }
            console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
            console.log('📋 最终配置:');
            console.log(`   策略类型: ${strategyType === 'grid' ? '网格模式' : '单档模式'}`);
            if (strategyType === 'grid') {
                console.log(`   网格档数: 根据余额自动调整`);
            }
            console.log(`   积分档位: ${mode === 'aggressive' ? '网格100 (100%)' : '网格50 (50%)'}`);
            console.log(`   网格范围: ${spreadBps}-${spreadBpsMax} bps`);
            console.log(`   最大漂移: ${maxBpsDrift} bps`);
            if (mode === 'aggressive') {
                console.log(`   Uptime目标: 70%+ (1.0x乘数)`);
            }
            console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
            resolve({
                mode,
                grid: strategyType === 'grid',
                gridCount,
                spreadBps,
                spreadBpsMax,
                maxBpsDrift
            });
        });
    });
}
function setStrategyEnv(strategyConfig) {
    process.env.STRATEGY_MODE = strategyConfig.mode;
    process.env.GRID_ENABLED = strategyConfig.grid ? 'true' : 'false';
    process.env.GRID_COUNT = strategyConfig.gridCount.toString();
    if (strategyConfig.spreadBps) {
        process.env.SPREAD_BPS = strategyConfig.spreadBps.toString();
    }
    if (strategyConfig.spreadBpsMax) {
        process.env.SPREAD_BPS_MAX = strategyConfig.spreadBpsMax.toString();
    }
    if (strategyConfig.maxBpsDrift) {
        process.env.MAX_BPS_DRIFT = strategyConfig.maxBpsDrift.toString();
    }
}
class StandXWebSocket extends EventEmitter {
    constructor(baseUrl, auth, proxyUrl = null, mode = 'stream', options = {}) {
        super();
        this.auth = auth;
        this.proxyUrl = proxyUrl;
        this.baseUrl = baseUrl;
        this.mode = mode;
        this.externalTimestampFn = options.externalTimestampFn || null;
        this.ws = null;
        this.pingInterval = null;
        this.reconnectTimeout = null;
        this.isAuthenticated = false;
        this.isConnecting = false;
        this.subscriptions = new Set();
        this.sessionId = crypto.randomUUID();
        this.pendingRequests = new Map();
        this.balance = null;
        this.positions = [];
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 50;
        this.baseReconnectDelay = 3000;
        this.maxReconnectDelay = 60000;
        this.lastPongTime = Date.now();
        this.pongTimeout = 60000;
        this.serverTimeOffset = 0;
        this.lastTimeSyncAt = 0;
        this.timeSyncInterval = 300000;
        this.connectionStartTime = null;
        this.maxConnectionDuration = 23 * 60 * 60 * 1000;
    }
    async syncServerTime() {
        try {
            const localBefore = Date.now();
            const res = await axios.get('https://geo.standx.com/v1/region', {
                timeout: 3000
            });
            const localAfter = Date.now();
            const serverTime = parseInt(res.data.systemTime, 10);
            const latency = (localAfter - localBefore) / 2;
            const estimatedServerTime = serverTime + latency;
            this.serverTimeOffset = estimatedServerTime - localAfter;
            this.lastTimeSyncAt = localAfter;
            console.log(`⏰ 时间同步完成: 偏移 ${this.serverTimeOffset > 0 ? '+' : ''}${this.serverTimeOffset}ms`);
        } catch (e) {
            console.log(`⚠️ 时间同步失败: ${e.message}`);
        }
    }
    async getServerTimestamp() {
        if (this.externalTimestampFn) {
            return await this.externalTimestampFn();
        }
        if (this.lastTimeSyncAt === 0) {
            await this.syncServerTime();
        }
        else if (Date.now() - this.lastTimeSyncAt > this.timeSyncInterval) {
            this.syncServerTime().catch(() => { });
        }
        return Date.now() + this.serverTimeOffset;
    }
    getSyncedTimestamp() {
        if (Date.now() - this.lastTimeSyncAt > this.timeSyncInterval) {
            this.syncServerTime().catch(() => { });
        }
        return Date.now() + this.serverTimeOffset;
    }
    connect() {
        if (this.ws || this.isConnecting) return;
        this.isConnecting = true;
        const options = {};
        if (this.proxyUrl) {
            const normalizedProxy = normalizeProxyUrl(this.proxyUrl);
            if (normalizedProxy) {
                options.agent = new HttpsProxyAgent(normalizedProxy);
            }
        }
        console.log(`📡正在连接 WebSocket: ${this.baseUrl}`);
        this.ws = new WebSocket(this.baseUrl, options);
        this.ws.on('open', () => {
            console.log('✅ WebSocket 已连接');
            this.isConnecting = false;
            this.reconnectAttempts = 0;
            this.lastPongTime = Date.now();
            this.connectionStartTime = Date.now();
            this.syncServerTime().catch(() => { });
            this.startHeartbeat();
            this.emit('connected');
            if (this.auth && this.auth.token) {
                this.login();
            }
        });
        this.ws.on('pong', () => {
            this.lastPongTime = Date.now();
        });
        this.ws.on('message', (data) => {
            try {
                const msg = JSON.parse(data.toString());
                this.handleMessage(msg);
            } catch (e) {
                console.error('❌ WS 解析错误:', e);
            }
        });
        this.ws.on('close', () => {
            console.log('⚠️ WebSocket 已断开');
            this.cleanup();
            this.emit('disconnected');
            this.scheduleReconnect();
        });
        this.ws.on('error', (err) => {
            console.error('❌ WebSocket 错误:', err.message);
            if (this.ws) {
                try { this.ws.close(); } catch (e) { /* ignore */ }
            }
        });
    }
    login() {
        if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
        if (this.mode === 'stream') {
            const authPayload = {
                auth: {
                    token: this.auth.token,
                    streams: [
                        { channel: 'order' },
                        { channel: 'position' },
                        { channel: 'balance' }
                    ]
                }
            };
            this.send(authPayload);
            console.log('📤 Market Stream 认证请求已发送');
        } else {
            this.request('auth:login', { token: this.auth.token })
                .then((res) => {
                    console.log('✅ WS API 认证成功');
                    this.isAuthenticated = true;
                    this.emit('authenticated', res);
                })
                .catch(err => {
                    console.error('❌ WS API 认证失败:', err.message);
                    this.emit('auth_failed', err);
                });
        }
    }
    subscribe(channel, symbol = null) {
        const subKey = symbol ? `${channel}:${symbol}` : channel;
        if (this.subscriptions.has(subKey) && !['order', 'position', 'balance'].includes(channel)) return;
        const payload = {
            subscribe: {
                channel: channel
            }
        };
        if (symbol) {
            payload.subscribe.symbol = symbol;
        }
        this.send(payload);
        this.subscriptions.add(subKey);
    }
    send(data) {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(typeof data === 'string' ? data : JSON.stringify(data));
        }
    }
    async request(method, params = {}, sign = false) {
        if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
            throw new Error('WebSocket未连接');
        }
        const requestId = crypto.randomUUID();
        const payload = {
            session_id: this.sessionId,
            request_id: requestId,
            method: method,
            params: JSON.stringify(params)
        };
        if (sign && this.auth) {
            const timestamp = await this.getServerTimestamp();
            const signHeaders = this.auth.signRequest(payload.params, requestId, timestamp);
            payload.header = signHeaders;
        }
        return new Promise((resolve, reject) => {
            const timeout = setTimeout(() => {
                if (this.pendingRequests.has(requestId)) {
                    this.pendingRequests.delete(requestId);
                    reject(new Error(`WS request timeout: ${method}`));
                }
            }, 10000);
            this.pendingRequests.set(requestId, { resolve, reject, timeout });
            this.send(payload);
        });
    }
    waitForReady(timeout = 20000) {
        if (this.isAuthenticated && this.ws?.readyState === WebSocket.OPEN) {
            return Promise.resolve();
        }
        return new Promise((resolve, reject) => {
            const timer = setTimeout(() => {
                cleanup();
                reject(new Error('WebSocket connection timeout'));
            }, timeout);
            const onAuth = () => {
                cleanup();
                resolve();
            };
            const onDisconnect = () => {
                cleanup();
                reject(new Error('WebSocket disconnected during wait'));
            };
            const cleanup = () => {
                clearTimeout(timer);
                this.removeListener('authenticated', onAuth);
                this.removeListener('disconnected', onDisconnect);
            };
            this.on('authenticated', onAuth);
            this.on('disconnected', onDisconnect);
        });
    }
    placeOrder(order) {
        return this.request('order:new', order, true);
    }
    cancelOrder(orderId) {
        return this.request('order:cancel', { order_id: orderId }, true);
    }
    handleMessage(msg) {
        const requestId = msg.request_id || msg.id;
        if (requestId && this.pendingRequests.has(requestId)) {
            const req = this.pendingRequests.get(requestId);
            clearTimeout(req.timeout);
            this.pendingRequests.delete(requestId);
            if (msg.code !== undefined && msg.code !== 0) {
                req.reject(new Error(msg.message || `Error ${msg.code}`));
            } else if (msg.error) {
                req.reject(new Error(msg.error));
            } else {
                req.resolve(msg.data || msg);
            }
            return;
        }
        if (msg.channel === 'auth' && msg.data) {
            const isSuccess = msg.data.code === 200 || msg.data.code === 0 ||
                msg.data.msg === 'success' || msg.data.message === 'success';
            if (isSuccess) {
                if (!this.isAuthenticated) {
                    console.log('✅ Market Stream 认证成功');
                    this.isAuthenticated = true;
                    this.emit('authenticated', msg);
                }
            } else {
                console.error('❌ Market Stream 认证失败:', msg.data.msg || msg.data.message || msg.data);
                this.emit('auth_failed', new Error(msg.data.msg || msg.data.message || 'Auth failed'));
            }
            return;
        }
        if (msg.code !== undefined && msg.message && !msg.channel) {
            const isSuccess = msg.code === 0 && msg.message === 'success';
            if (isSuccess && !this.isAuthenticated) {
                console.log('✅ 认证成功');
                this.isAuthenticated = true;
                this.emit('authenticated', msg);
            }
            return;
        }
        if (msg.channel === 'depth_book' && msg.data) {
            this.emit('depth', msg.data);
            return;
        }
        if (msg.channel === 'price' && msg.data) {
            this.emit('price', msg.data);
            return;
        }
        if (msg.channel === 'order' && msg.data) {
            this.emit('order', msg.data);
            return;
        }
        if (msg.channel === 'balance' && msg.data) {
            this.balance = msg.data;
            this.emit('balance', msg.data);
            return;
        }
        if (msg.channel === 'position' && msg.data) {
            this.positions = Array.isArray(msg.data) ? msg.data : [msg.data];
            this.emit('position', this.positions);
            return;
        }
        if (msg.channel === 'public_trade' && msg.data) {
            this.emit('public_trade', msg.data);
            return;
        }
        if (msg.channel === 'trade' && msg.data) {
            this.emit('trade', msg.data);
            return;
        }
        if (msg.pong) {
            return;
        }
    }
    startHeartbeat() {
        if (this.pingInterval) clearInterval(this.pingInterval);
        this.pingInterval = setInterval(() => {
            if (this.ws && this.ws.readyState === WebSocket.OPEN) {
                const timeSinceLastPong = Date.now() - this.lastPongTime;
                if (timeSinceLastPong > this.pongTimeout) {
                    console.log(`⚠️ WebSocket 心跳超时 (${Math.floor(timeSinceLastPong / 1000)}s)，强制重连...`);
                    this.ws.terminate();
                    return;
                }
                if (this.connectionStartTime && Date.now() - this.connectionStartTime > this.maxConnectionDuration) {
                    const hours = Math.floor((Date.now() - this.connectionStartTime) / 3600000);
                    console.log(`⏰ WebSocket 连接达到 ${hours} 小时，主动重连以避免服务器断开...`);
                    this.ws.terminate();
                    return;
                }
                this.ws.ping();
            }
        }, 5000);
    }
    cleanup() {
        this.isAuthenticated = false;
        this.isConnecting = false;
        if (this.pingInterval) clearInterval(this.pingInterval);
        this.ws = null;
        for (const [id, req] of this.pendingRequests) {
            clearTimeout(req.timeout);
            req.reject(new Error('WS connection closed'));
        }
        this.pendingRequests.clear();
    }
    scheduleReconnect() {
        if (this.reconnectTimeout) clearTimeout(this.reconnectTimeout);
        if (this.reconnectAttempts >= this.maxReconnectAttempts) {
            console.error('❌ WebSocket 重连次数已达上限，停止重连');
            this.emit('max_reconnect_reached');
            return;
        }
        const delay = Math.min(
            this.baseReconnectDelay * Math.pow(2, this.reconnectAttempts),
            this.maxReconnectDelay
        );
        this.reconnectAttempts++;
        this.reconnectTimeout = setTimeout(() => {
            console.log(`🔄 尝试重连 WebSocket... (${this.reconnectAttempts}/${this.maxReconnectAttempts})`);
            this.connect();
        }, delay);
    }
    resubscribe() {
        for (const sub of this.subscriptions) {
            const [channel, symbol] = sub.split(':');
            this.subscribe(channel, symbol === 'undefined' ? null : symbol);
        }
    }
    close() {
        if (this.reconnectTimeout) clearTimeout(this.reconnectTimeout);
        if (this.pingInterval) clearInterval(this.pingInterval);
        if (this.ws) {
            this.ws.close();
            this.ws = null;
        }
    }
}
class StandXAuth {
    constructor(proxyUrl = null) {
        const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
        this._privateKey = privateKey;
        const spkiDer = crypto.createPublicKey(this._privateKey).export({ format: 'der', type: 'spki' });
        this._publicKeyBytes = spkiDer.subarray(spkiDer.length - 32);
        this.requestId = this._base58Encode(this._publicKeyBytes);
        this.baseUrl = 'https://api.standx.com';
        this.axiosConfig = {};
        const normalizedProxyUrl = normalizeProxyUrl(proxyUrl);
        if (normalizedProxyUrl) {
            this.axiosConfig.httpsAgent = new HttpsProxyAgent(normalizedProxyUrl, {
                keepAlive: true,
                keepAliveMsecs: 10000,
                scheduling: 'fifo'
            });
            this.axiosConfig.proxy = false;
        } else {
            this.axiosConfig.httpsAgent = new https.Agent({
                keepAlive: true,
                keepAliveMsecs: 10000,
                scheduling: 'fifo'
            });
        }
    }
    _base58Encode(buffer) {
        const alphabet = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
        let x = 0n;
        for (const b of buffer) x = (x << 8n) + BigInt(b);
        let out = '';
        while (x > 0n) { out = alphabet[Number(x % 58n)] + out; x = x / 58n; }
        for (let i = 0; i < buffer.length && buffer[i] === 0; i++) out = '1' + out;
        return out || '1';
    }
    _parseJwt(token) {
        const parts = token.split('.');
        return JSON.parse(Buffer.from(parts[1], 'base64url').toString());
    }
    async authenticate(chain, walletAddress, signMessageFn) {
        const prepareRes = await axios.post(`${this.baseUrl}/v1/offchain/prepare-signin?chain=${chain}`,
            { address: walletAddress, requestId: this.requestId },
            {
                headers: { 'Content-Type': 'application/json' },
                timeout: 10000,
                ...this.axiosConfig
            }
        );
        const signedDataJwt = prepareRes.data.signedData;
        const payload = this._parseJwt(signedDataJwt);
        const signature = await signMessageFn(payload.message);
        const loginRes = await axios.post(`${this.baseUrl}/v1/offchain/login?chain=${chain}`,
            { signature, signedData: signedDataJwt, expiresSeconds: 604800 },
            {
                headers: { 'Content-Type': 'application/json' },
                timeout: 10000,
                ...this.axiosConfig
            }
        );
        return loginRes.data;
    }
    signRequest(payload, requestId, timestamp) {
        const message = `v1,${requestId},${timestamp},${payload}`;
        const signature = crypto.sign(null, Buffer.from(message, 'utf8'), this._privateKey);
        return {
            'x-request-sign-version': 'v1',
            'x-request-id': requestId,
            'x-request-timestamp': String(timestamp),
            'x-request-signature': signature.toString('base64')
        };
    }
}
class StandXAPI {
    constructor(baseUrl = 'https://perps.standx.com', geoUrl = 'https://geo.standx.com', proxyUrl = null) {
        this.baseUrl = baseUrl;
        this.geoUrl = geoUrl;
        this.axiosConfig = {};
        const normalizedProxyUrl = normalizeProxyUrl(proxyUrl);
        if (normalizedProxyUrl) {
            this.proxyUrl = normalizedProxyUrl;
            this.axiosConfig.httpsAgent = new HttpsProxyAgent(normalizedProxyUrl);
            this.axiosConfig.proxy = false;
            console.log(`🌐 使用代理: ${normalizedProxyUrl.replace(/\/\/.*:.*@/, '//***:***@')}`);
        }
    }
    async getDepthBook(symbol) {
        const res = await axios.get(`${this.baseUrl}/api/query_depth_book`, {
            params: { symbol },
            timeout: 3000,
            ...this.axiosConfig
        });
        return res.data;
    }
    async getSymbolInfo(symbol) {
        try {
            // 官方文档: GET /api/query_symbol_info
            const res = await axios.get(`${this.baseUrl}/api/query_symbol_info`, {
                params: { symbol },
                timeout: 5000,
                ...this.axiosConfig
            });
            // 返回的是数组，如 [{ symbol: 'BTC-USD', ... }]
            if (Array.isArray(res.data) && res.data.length > 0) {
                return res.data.find(s => s.symbol === symbol) || res.data;
            }
            return res.data;
        } catch (e) {
            console.log(`⚠️ 获取交易对信息失败: ${e.message}`);
            return null;
        }
    }
    async getPrice(symbol) {
        // 官方文档: GET /api/query_symbol_price
        const res = await axios.get(`${this.baseUrl}/api/query_symbol_price`, {
            params: { symbol },
            timeout: 3000,
            ...this.axiosConfig
        });
        // 返回格式: { mark_price: "121602.43", ... }
        return res.data;
    }
    async request(method, endpoint, token, data = {}, auth = null) {
        const url = `${this.baseUrl}${endpoint}`;
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
        };

        if (auth && data) {
            // 如果需要签名 (通常 POST 请求)
            const requestId = auth.requestId; // 假设 auth 对象包含了 requestId, 或者应该从 StandXAuth 实例获取?
            // 之前的调用: this.api.request('POST', '...', this.token, payload, this.auth);
            // StandXMakerBot 中: this.auth 是 StandXAuth 实例

            // 注意: 根据 StandXAuth.signRequest 定义: signRequest(payload, requestId, timestamp)
            // 这里我们需要生成 requestId 和 timestamp
            const ts = Date.now();
            // 这里假设 auth 传入的是 StandXAuth 实例

            // 重要: 原代码中 request 调用传入了 this.auth。
            // 我们检查 StandXAuth 的 signRequest 方法。

            // 如果是私有请求，通常需要签名
            const payloadStr = JSON.stringify(data);
            const signHeaders = auth.signRequest(payloadStr, auth.requestId, ts);
            Object.assign(headers, signHeaders);
        }

        const config = {
            method,
            url,
            headers,
            timeout: 10000,
            ...this.axiosConfig
        };

        if (method.toUpperCase() === 'GET') {
            config.params = data;
        } else {
            config.data = data;
        }

        try {
            const response = await axios(config);
            return response.data;
        } catch (error) {
            // 简单的错误透传，保留原始错误信息以便上层处理
            throw error;
        }
    }
    async getCachedPrice(symbol, cache) {
        const now = Date.now();
        if (cache.price && (now - cache.timestamp) < cache.ttl) {
            return cache.price;
        }
        const priceData = await this.getPrice(symbol);
        cache.price = parseFloat(priceData.mark_price);
        cache.timestamp = now;
        return cache.price;
    }
    async getADX(symbol, interval = '5m', period = 14) {
        return fetchADX(symbol, interval, period);
    }
    async getRSI(symbol, interval = '5m', period = 14) {
        return fetchRSI(symbol, interval, period);
    }
    async getTimestamp() {
        // 获取服务器时间用于签名
        try {
            const res = await axios.get(`${this.geoUrl}/v1/region`, {
                timeout: 3000,
                ...this.axiosConfig
            });
            return parseInt(res.data.systemTime, 10);
        } catch (e) {
            // 如果获取失败，返回本地时间
            return Date.now();
        }
    }
}
class StandXMakerBot {
    constructor() {
        this.privateKey = process.env.PRIVATE_KEY;
        if (!this.privateKey) throw new Error('请设置 PRIVATE_KEY');
        this.symbol = process.env.SYMBOL || 'BTC-USD';
        this.strategyMode = process.env.STRATEGY_MODE || 'aggressive';
        const modeConfig = this.strategyMode === 'conservative'
            ? STRATEGY_CONFIG.conservative
            : STRATEGY_CONFIG.aggressive;
        const commonConfig = STRATEGY_CONFIG.common;
        this.spreadBps = parseFloat(process.env.SPREAD_BPS || modeConfig.spreadBps);
        this.spreadBpsMax = modeConfig.spreadBpsMax || modeConfig.maxBpsDrift;
        this.maxBpsForRange = modeConfig.maxBpsForRange;
        this.minBpsForRange = modeConfig.minBpsForRange || 0;
        this.pointsMultiplier = modeConfig.pointsMultiplier;
        this.dangerBpsDefault = modeConfig.dangerBps;
        this.gridStep = parseFloat(process.env.GRID_STEP || '50');
        this.maxEffectiveQtyPerSide = parseFloat(process.env.MAX_EFFECTIVE_QTY || commonConfig.maxEffectiveQtyPerSide);
        this.targetUptimePercent = commonConfig.targetUptimePercent;
        this.consecutiveFillsThreshold = commonConfig.consecutiveFillsThreshold;
        this.consecutiveFills = 0;
        this.originalSpreadBps = this.spreadBps;
        this.isConservativeMode = false;
        this.conservativeModeUntil = 0;
        this.currentRSI = null;
        this.lastRSIUpdate = 0;
        this.rsiUpdateInterval = 60000;
        this.rsiOversold = commonConfig.rsiOversold;
        this.rsiOverbought = commonConfig.rsiOverbought;
        this.gridEnabled = process.env.GRID_ENABLED === 'true';
        this.gridCount = parseInt(process.env.GRID_COUNT || '1');
        this.gridStep = parseFloat(process.env.GRID_STEP || '50');
        this.gridMaxSpreadPercent = parseFloat(process.env.GRID_MAX_SPREAD_PERCENT || '0.01');
        this.refreshInterval = parseInt(process.env.REFRESH_INTERVAL || commonConfig.refreshInterval);
        this.checkInterval = parseInt(process.env.CHECK_INTERVAL || '100');
        this.priceMonitorInterval = parseInt(process.env.PRICE_MONITOR_INTERVAL || '100');
        this.fixedOrderQty = parseFloat(process.env.ORDER_AMOUNT || '0');
        this.smartOrderManagement = process.env.SMART_ORDER_MANAGEMENT !== 'false';
        this.adxEnabled = process.env.ADX_ENABLED === 'true';
        this.adxThreshold = parseFloat(process.env.ADX_THRESHOLD || '25');
        this.adxMax = parseFloat(process.env.ADX_MAX || '60');
        this.adxUpdateInterval = parseInt(process.env.ADX_UPDATE_INTERVAL || '60000');
        this.currentADX = null;
        this.lastADXUpdate = 0;
        this.dangerBps = parseFloat(process.env.DANGER_BPS || this.dangerBpsDefault.toString());
        this.volatilityThreshold = parseFloat(process.env.VOLATILITY_THRESHOLD || modeConfig.volatilityThreshold);
        this.volatilityProtectionDelay = parseInt(process.env.VOLATILITY_PROTECTION_DELAY || modeConfig.volatilityDelay);
        this.targetLeverage = parseInt(process.env.TARGET_LEVERAGE || commonConfig.targetLeverage);
        this.marginRatio = parseFloat(process.env.MARGIN_RATIO || commonConfig.marginRatio);
        this.minAvailableBalance = parseFloat(process.env.MIN_BALANCE || '1');
        this.maxLoss = parseFloat(process.env.MAX_LOSS || commonConfig.maxLoss);
        this.lossProtectionEnabled = process.env.LOSS_PROTECTION !== 'false';
        this.lossCheckInterval = parseInt(process.env.LOSS_CHECK_INTERVAL || '30000');
        this.lossProtectionTriggered = false;
        this.smartRefresh = process.env.SMART_REFRESH !== 'false';
        this.lastMarkPrice = null;
        this.priceChangeThreshold = 0.0003;
        this.isMonitoringBuy = false;
        this.isMonitoringSell = false;
        this.buyMonitorTimer = null;
        this.sellMonitorTimer = null;
        this.priceCache = {
            price: null,
            timestamp: 0,
            ttl: 200
        };
        this.priceHistory = [];
        this.maxPriceHistory = 10;
        this.lastVolatilityCheck = 0;
        this.isHighVolatility = false;
        this.volatilityPauseUntil = 0;
        this.currentLeverage = null;
        this.maxLeverage = 40;
        this.proxyUrl = process.env.PROXY_URL || null;
        this.wallet = new ethers.Wallet(this.privateKey);
        this.auth = new StandXAuth(this.proxyUrl);
        this.api = new StandXAPI('https://perps.standx.com', 'https://geo.standx.com', this.proxyUrl);
        this.token = null;
        this.tokenExpiry = 0;
        this.maxRetries = 3;
        this.retryDelay = 1000;
        this.consecutiveErrors = 0;
        this.maxConsecutiveErrors = 10;
        this.lastSuccessfulOperation = Date.now();
        this.healthCheckInterval = 300000;
        this.maxIdleTime = 300000;
        this.apiErrorCount = 0;
        this.maxApiErrors = 20;
        this.ws = new StandXWebSocket('wss://perps.standx.com/ws-stream/v1', this.auth, process.env.HTTPS_PROXY, 'stream');
        this.wsApi = new StandXWebSocket('wss://perps.standx.com/ws-api/v1', this.auth, process.env.HTTPS_PROXY, 'api', {
            externalTimestampFn: () => this.api.getTimestamp()
        });
        this.isWsConnected = false;
        this.lastWsPriceUpdate = 0;
        this.lastWsOrderUpdate = 0;
        this.cachedOpenOrders = new Map();
        this.recentlyFilledOrders = new Set();
        this.initialOrderSyncDone = false;
        this.uptimeStats = {
            currentHourStart: Math.floor(Date.now() / 3600000) * 3600000,
            snapshots: [],
            lastCheckTime: Date.now(),
            totalHours: 0,
            qualifiedHours: 0,
            boostedHours: 0,
        };
        this.dynamicRefreshInterval = this.refreshInterval;
        this.maxRefreshInterval = 60000;
        this.minRefreshInterval = 10000;
        this.setupWebSocketEvents();
    }
    setupWebSocketEvents() {
        this.ws.on('connected', async () => {
            console.log('✅ 市场流 WebSocket 已连接');
            this.isWsConnected = true;
            try {
                await this.ensureValidToken();
            } catch (e) {
                console.log('⚠️ Token 刷新失败，继续使用现有 token');
            }
            this.ws.subscribe('price', this.symbol);
            this.ws.subscribe('depth_book', this.symbol);
        });
        this.ws.on('disconnected', () => {
            console.log('⚠️ 市场流 WebSocket 断开连接');
            this.isWsConnected = false;
            this.initialOrderSyncDone = false;
        });
        this.ws.on('authenticated', async () => {
            console.log('🔐 市场流 认证成功，同步订单');
            this.ws.resubscribe();
            try {
                await this.getOpenOrders(true);
            } catch (e) { }
        });
        this.wsApi.on('connected', () => {
            console.log('✅ 操作流 WebSocket (API) 已连接');
        });
        this.wsApi.on('authenticated', () => {
            console.log('🔐 操作流 认证成功，下单功能就绪');
        });
        this.wsApi.on('disconnected', async () => {
            console.log('⚠️ 操作流 WebSocket 断开连接');
            // 断开时标记连接状态，防止下单
            this.isWsConnected = false;
        });

        // 市场流断开时取消所有挂单（安全措施）
        this.ws.on('disconnected', async () => {
            console.log('⚠️ 市场流断开，取消挂单等待恢复...');
            this.isWsConnected = false;
            if (this.currentOrderIds.length > 0 && !this.isExiting) {
                try {
                    await this.cancelOrders(this.currentOrderIds);
                    this.currentOrderIds = [];
                    this.currentOrders = [];
                    console.log('✅ 挂单已取消，等待连接恢复后重新挂单');
                } catch (e) {
                    console.log('⚠️ 断线取消订单失败:', e.message);
                }
            }
        });
        this.ws.on('price', (data) => {
            if (data.symbol !== this.symbol) return;
            const markPrice = parseFloat(data.mark_price);
            this.lastWsPriceUpdate = Date.now();
            this.isWsConnected = true;
            this.markSuccessfulOperation();
            if (this.shouldRefreshOrders(markPrice)) {
                this.refreshGridOrders(markPrice, null);
            }
        });
        this.ws.on('depth', (data) => {
            if (data.symbol !== this.symbol) return;
            this.lastWsDepthUpdate = Date.now();
            this.isWsConnected = true;
            if (data.bids && data.bids.length > 0) {
                this.sharedDepthBook = this.sharedDepthBook || {};
                this.sharedDepthBook.bestBid = parseFloat(data.bids[0][0]);
            }
            if (data.asks && data.asks.length > 0) {
                this.sharedDepthBook = this.sharedDepthBook || {};
                this.sharedDepthBook.bestAsk = parseFloat(data.asks[0][0]);
            }
        });
        this.ws.on('order', async (data) => {
            this.isWsConnected = true;
            if (data.status === 'filled' || data.status === 'partially_filled') {
                const uniqueId = data.id || data.cl_ord_id;
                if (uniqueId && this.recentlyFilledOrders.has(uniqueId)) {
                    return;
                }
                let distanceInfo = '';
                if (data.price && this.lastMarkPrice) {
                    const orderPrice = parseFloat(data.price);
                    const bps = data.side === 'buy'
                        ? (this.lastMarkPrice - orderPrice) / this.lastMarkPrice * 10000
                        : (orderPrice - this.lastMarkPrice) / this.lastMarkPrice * 10000;
                    distanceInfo = ` (${bps.toFixed(1)}bps)`;
                }
                console.log(`🔔 订单${data.status === 'filled' ? '成交' : '部分成交'}: ${data.side} @ ${data.price}${distanceInfo}`);
            }
            this.markSuccessfulOperation();
            if (data.id) {
                if (data.status === 'new' || data.status === 'partially_filled') {
                    this.cachedOpenOrders.set(data.id, data);
                } else {
                    this.cachedOpenOrders.delete(data.id);
                    if (data.status === 'filled') {
                        this.recentlyFilledOrders.add(data.id);
                        if (data.cl_ord_id) this.recentlyFilledOrders.add(data.cl_ord_id);
                        if (this.recentlyFilledOrders.size > 1000) {
                            const toDelete = Array.from(this.recentlyFilledOrders).slice(0, 500);
                            toDelete.forEach(id => this.recentlyFilledOrders.delete(id));
                        }
                        const orderId = data.id;
                        const clOrdId = data.cl_ord_id;
                        setTimeout(() => {
                            if (!this.isExiting) {
                                this.recentlyFilledOrders.delete(orderId);
                                if (clOrdId) this.recentlyFilledOrders.delete(clOrdId);
                            }
                        }, 5000);
                    }
                }
            }
            if (data.status === 'rejected' || data.status === 'cancelled') {
                setImmediate(() => this.refreshOrders());
            } else if (data.status === 'filled' || data.status === 'partially_filled') {
                console.log(`🎉 订单成交! 立即刷新网格`);
                setImmediate(() => this.refreshOrders());
                setImmediate(() => this.checkAndClosePositions());
            }
        });
        this.consecutivePostOnlyRejects = 0;
        this.spreadAdjustment = 0;
        this.buySpreadAdjust = 0;
        this.sellSpreadAdjust = 0;
        this.maxSpreadAdjust = 2.5;
        this.currentOrderIds = [];
        this.currentOrders = [];
        this.isRefreshing = false;
        this.isSupplementing = false;
        this.isClosingPosition = false;
        this.isExiting = false;
        this.stats = {
            startTime: Date.now(),
            ordersPlaced: 0,
            ordersFilled: 0,
            totalPnl: 0,
            estimatedPoints: 0,
            totalNotionalTime: 0,
            lastUpdateTime: Date.now(),
            initialBalance: null,
            highestBalance: null,
            lowestBalance: null,
            lastBalance: null
        };
        const modeIcon = this.strategyMode === 'aggressive' ? '🔴' : '🟡';
        const shortAddr = `${this.wallet.address.slice(0, 6)}...${this.wallet.address.slice(-4)}`;
        console.log(`📋 ${shortAddr} | ${this.strategyMode === 'aggressive' ? '激进' : '保守'} | ${this.spreadBps}bps | ${this.targetLeverage}x | 损耗$${this.maxLoss}`);
        if (this.strategyMode === 'conservative') {
            console.log('⚠️  注意: 保守模式 (10-30 bps) 不符合 Maker Uptime 要求 (需 <10 bps)');
            console.log('   可获得 50% Maker Points，但不计入月度 Uptime 代币奖励');
        }
    }
    async init() {
        await this.refreshToken();
        await this.getSymbolConfig();
        await this.detectCurrentLeverage();
        if (this.currentLeverage !== this.targetLeverage) {
            await this.changeLeverage(this.targetLeverage);
        }
    }
    async refreshToken() {
        console.log('🔐 正在认证...');
        const loginRes = await this.auth.authenticate('bsc', this.wallet.address,
            async (msg) => await this.wallet.signMessage(msg));
        this.token = loginRes.token;
        this.tokenExpiry = Date.now() + (7 * 24 - 1) * 60 * 60 * 1000;
        this.auth.token = this.token;
        console.log('✅ 认证成功\n');
    }
    async ensureValidToken() {
        try {
            if (Date.now() > this.tokenExpiry - 3600000) {
                console.log('🔄 Token 即将过期，刷新中...');
                await this.refreshToken();
            }
        } catch (e) {
            console.error('Token 刷新失败:', e.message);
            if (Date.now() < this.tokenExpiry) {
                console.log('⚠️ Token 刷新失败但当前 Token 仍有效，稍后重试');
            } else {
                throw e;
            }
        }
    }
    async healthCheck() {
        const now = Date.now();

        // 使用 pong 心跳来判断连接健康，而不是数据更新频率
        // StandX 服务器每 10 秒发送 ping，5 分钟无响应才断开
        // 所以我们用 60 秒无 pong 作为僵尸连接的判断标准
        const wsPongAge = this.ws ? (now - (this.ws.lastPongTime || now)) : 0;
        const wsApiPongAge = this.wsApi ? (now - (this.wsApi.lastPongTime || now)) : 0;
        const maxPongAge = Math.max(wsPongAge, wsApiPongAge);

        // 如果 60 秒没收到 pong，说明连接可能有问题
        const isZombieConnection = this.isWsConnected && maxPongAge > 60000;
        if (isZombieConnection) {
            console.log(`⚠️ WS 心跳超时: ${Math.floor(maxPongAge / 1000)}s 无 pong 响应，触发重连...`);
            this.isWsConnected = false;
            return;
        }
        if (now - this.lastSuccessfulOperation > this.maxIdleTime) {
            console.log('\n⚠️  检测到长时间无成功操作，尝试重新认证...');
            try {
                await this.refreshToken();
                this.lastSuccessfulOperation = now;
                this.apiErrorCount = 0;
                console.log('✅ 重新认证成功\n');
            } catch (e) {
                console.log(`❌ 重新认证失败: ${e.message}`);
            }
        }
        if (this.apiErrorCount >= this.maxApiErrors) {
            console.log(`\n⚠️  API 错误过多 (${this.apiErrorCount}次)，暂停 30 秒...`);
            await new Promise(r => setTimeout(r, 30000));
            this.apiErrorCount = 0;
            try {
                await this.refreshToken();
                console.log('✅ 重新认证成功，继续运行\n');
            } catch (e) {
                console.log(`❌ 重新认证失败: ${e.message}`);
            }
        }
    }
    markSuccessfulOperation() {
        this.lastSuccessfulOperation = Date.now();
        this.apiErrorCount = 0;
        this.consecutiveErrors = 0;
    }
    markApiError() {
        this.apiErrorCount++;
        this.consecutiveErrors++;
    }
    async getSymbolConfig() {
        const maxRetries = 3;
        for (let attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                console.log('📊 获取交易对配置...');
                const info = await this.api.getSymbolInfo(this.symbol);
                // 处理数组或对象响应
                let config = null;
                if (Array.isArray(info) && info.length > 0) {
                    config = info.find(s => s.symbol === this.symbol) || info[0];
                } else if (info && typeof info === 'object' && info.symbol) {
                    config = info;
                }

                if (config) {
                    this.maxLeverage = parseInt(config.max_leverage) || 40;
                    this.minOrderQty = parseFloat(config.min_order_qty) || 0.0001;
                    this.maxOrderQty = parseFloat(config.max_order_qty) || 100;
                    this.qtyStep = parseFloat(config.qty_step) || 0.001;
                    this.tickSize = parseFloat(config.tick_size) || 0.01;
                    const modeStr = this.strategyMode === 'aggressive' ? '激进 0-10bps' : '保守 10-30bps';
                    console.log(`   ${modeStr} | 挂单${this.spreadBps}bps | 危险${this.dangerBps}bps | 杠杆${this.maxLeverage}x`);
                    console.log(`   最小数量: ${this.minOrderQty} | 数量步长: ${this.qtyStep} | 价格步长: ${this.tickSize}`);
                    if (this.targetLeverage > this.maxLeverage) {
                        console.log(`⚠️ 目标杠杆 ${this.targetLeverage}x 超过最大 ${this.maxLeverage}x，调整为 ${this.maxLeverage}x`);
                        this.targetLeverage = this.maxLeverage;
                    }
                    return;
                }
            } catch (e) {
                console.log(`获取交易对配置失败 (${attempt}/${maxRetries}): ${e.message}`);
                if (attempt < maxRetries) {
                    const waitTime = attempt * 1000;
                    console.log(`   等待 ${waitTime / 1000} 秒后重试...`);
                    await new Promise(r => setTimeout(r, waitTime));
                }
            }
        }
        console.log('⚠️ 无法获取交易对配置，使用默认值');
        this.minOrderQty = 0.0001;
        this.maxOrderQty = 100;
        this.qtyStep = 0.001;
        this.tickSize = 0.01;
    }
    async detectCurrentLeverage() {
        console.log('\n🔍 检测当前杠杆设置...');
        try {
            const posConfig = await this.api.request('GET', '/api/query_position_config', this.token, { symbol: this.symbol });
            if (posConfig && posConfig.leverage) {
                this.currentLeverage = parseInt(posConfig.leverage);
                console.log(`   从持仓配置检测到杠杆: ${this.currentLeverage}x`);
                return;
            }
        } catch (e) {
        }
        try {
            const positions = await this.api.request('GET', '/api/query_positions', this.token, { symbol: this.symbol });
            if (positions && positions.length > 0) {
                for (const pos of positions) {
                    if (pos.leverage) {
                        this.currentLeverage = parseInt(pos.leverage);
                        console.log(`   从持仓检测到杠杆: ${this.currentLeverage}x`);
                        return;
                    }
                }
            }
        } catch (e) {
        }
        try {
            const orders = await this.api.request('GET', '/api/query_open_orders', this.token, { symbol: this.symbol });
            if (orders?.result?.length > 0) {
                for (const order of orders.result) {
                    if (order.leverage) {
                        this.currentLeverage = parseInt(order.leverage);
                        console.log(`   从订单检测到杠杆: ${this.currentLeverage}x`);
                        return;
                    }
                }
            }
        } catch (e) {
        }
        this.currentLeverage = 10;
        console.log(`   未检测到杠杆设置，假设默认: ${this.currentLeverage}x`);
    }
    async getCurrentPrice() {
        if (this.priceCache.price && this.priceCache.timestamp) {
            const age = Date.now() - this.priceCache.timestamp;
            if (age < 500) {
                return this.priceCache.price;
            }
        }
        if (this.sharedPriceMode && this.sharedPriceData && this.sharedPriceData.markPrice) {
            const age = Date.now() - this.sharedPriceData.timestamp;
            if (age < 1000) {
                return this.sharedPriceData.markPrice;
            }
        }
        const price = await this.api.getCachedPrice(this.symbol, this.priceCache);
        this.markSuccessfulOperation();
        return price;
    }
    async changeLeverage(newLeverage) {
        console.log(`\n🔧 正在修改杠杆: ${this.currentLeverage}x → ${newLeverage}x`);
        try {
            const payload = {
                symbol: this.symbol,
                leverage: newLeverage
            };
            const result = await this.api.request('POST', '/api/change_leverage', this.token, payload, this.auth);
            if (result?.code === 0) {
                this.currentLeverage = newLeverage;
                console.log(`✅ 杠杆修改成功: ${newLeverage}x`);
                return true;
            } else {
                console.log(`❌ 杠杆修改失败: ${result?.message || 'unknown'}`);
                return false;
            }
        } catch (e) {
            const errMsg = e.response?.data?.message || e.message;
            console.log(`❌ 杠杆修改异常: ${errMsg}`);
            if (errMsg.includes('position') || errMsg.includes('open')) {
                console.log('⚠️ 可能有持仓或挂单，需要先平仓/撤单才能修改杠杆');
            }
            return false;
        }
    }
    async getBalance() {
        if (this.ws && this.ws.balance) {
            const data = this.ws.balance;
            return {
                available: parseFloat(data.free || data.cross_available || 0),
                balance: parseFloat(data.total || data.balance || 0),
                equity: parseFloat(data.equity || data.total || 0),
                upnl: parseFloat(data.upnl || 0),
                locked: parseFloat(data.locked || 0)
            };
        }
        // 官方文档: GET /api/query_balance
        const data = await this.api.request('GET', '/api/query_balance', this.token);

        return {
            available: parseFloat(data.cross_available || 0),
            balance: parseFloat(data.balance || 0),
            equity: parseFloat(data.equity || 0),
            upnl: parseFloat(data.upnl || 0),
            locked: parseFloat(data.locked || 0)
        };
    }
    async cancelOrders(orderIds) {
        if (!orderIds || orderIds.length === 0) return;
        if (this.wsApi && this.wsApi.isAuthenticated && this.wsApi.ws?.readyState === WebSocket.OPEN) {
            try {
                const cancelPromises = orderIds.map(id =>
                    this.wsApi.cancelOrder(id).catch(e => {
                        return null;
                    })
                );
                await Promise.all(cancelPromises);
                return;
            } catch (e) {
                console.log(`⚠️ WS批量撤单异常: ${e.message}，降级到 REST...`);
            }
        }
        try {
            await this.api.request('POST', '/api/cancel_orders', this.token, { order_id_list: orderIds }, this.auth);
        } catch (error) {
            console.log(`撤单失败: ${error.message}`);
        }
    }
    updateUptimeStats(buyOrders, sellOrders, markPrice) {
        const now = Date.now();
        const currentHour = Math.floor(now / 3600000) * 3600000;
        if (currentHour > this.uptimeStats.currentHourStart) {
            const result = this.calculateMakerHours();
            this.uptimeStats.totalHours++;
            if (result.makerHours > 0) {
                this.uptimeStats.qualifiedHours++;
                if (result.tier === 'boosted') {
                    this.uptimeStats.boostedHours++;
                }
            }
            this.uptimeStats.currentHourStart = currentHour;
            this.uptimeStats.snapshots = [];
        }
        this.uptimeStats.lastCheckTime = now;
        const buyQty = Array.isArray(buyOrders) ? buyOrders.reduce((sum, o) => sum + parseFloat(o.qty || 0), 0) : (buyOrders ? 1 : 0);
        const sellQty = Array.isArray(sellOrders) ? sellOrders.reduce((sum, o) => sum + parseFloat(o.qty || 0), 0) : (sellOrders ? 1 : 0);
        const minSize = Math.min(buyQty, sellQty, 2);
        if (buyQty > 0 && sellQty > 0) {
            this.uptimeStats.snapshots.push({ time: now, minSize });
            // 限制快照数量，防止内存泄漏（最多保留3600个，约1小时的每秒快照）
            if (this.uptimeStats.snapshots.length > 3600) {
                this.uptimeStats.snapshots = this.uptimeStats.snapshots.slice(-3600);
            }
        }
    }
    calculateMakerHours() {
        const snapshots = this.uptimeStats.snapshots;
        if (snapshots.length === 0) {
            return { makerHours: 0, tier: 'none', uptime: 0 };
        }
        const sorted = [...snapshots].sort((a, b) => b.minSize - a.minSize);
        const total = sorted.length;
        const idx70 = Math.floor(total * 0.3);
        const idx50 = Math.floor(total * 0.5);
        const x70 = sorted[idx70]?.minSize || 0;
        const x50 = sorted[idx50]?.minSize || 0;
        const boosted = (x70 / 2) * 1.0;
        const standard = (x50 / 2) * 0.5;
        const makerHours = Math.max(boosted, standard);
        const hourElapsed = (Date.now() - this.uptimeStats.currentHourStart) / 1000;
        const activeSnapshots = snapshots.length;
        const expectedSnapshots = Math.floor(hourElapsed / 30);
        const uptime = expectedSnapshots > 0 ? Math.min(100, (activeSnapshots / expectedSnapshots) * 100) : 0;
        const tier = boosted >= standard ? 'boosted' : 'standard';
        return { makerHours, tier, uptime, x70, x50 };
    }
    getCurrentHourMakerHours() {
        return this.calculateMakerHours();
    }
    async checkLossProtection() {
        if (!this.lossProtectionEnabled || this.lossProtectionTriggered) {
            return false;
        }
        if (this.stats.initialBalance === null) {
            return false;
        }
        try {
            const balance = await this.getBalance();
            const currentBalance = balance.balance;
            const loss = this.stats.initialBalance - currentBalance;
            if (loss >= this.maxLoss) {
                this.lossProtectionTriggered = true;
                console.log(`\n${'!'.repeat(60)}`);
                console.log(`🚨 损耗保护触发！`);
                console.log(`   初始余额: $${this.stats.initialBalance.toFixed(2)}`);
                console.log(`   当前余额: $${currentBalance.toFixed(2)}`);
                console.log(`   累计损耗: $${loss.toFixed(2)} (阈值: $${this.maxLoss})`);
                console.log(`${'!'.repeat(60)}\n`);
                console.log('🛑 正在安全停止...');
                console.log('🗑️  正在取消所有挂单...');
                const orders = await this.getOpenOrders();
                if (orders.length > 0) {
                    await this.cancelOrders(orders.map(o => o.id));
                    console.log(`   ✅ 已取消 ${orders.length} 个挂单`);
                }
                console.log('📦 正在检查持仓...');
                await this.checkAndClosePositions();
                console.log('\n⚠️  程序已因损耗保护而停止');
                console.log(`💡 提示: 可以通过设置 MAX_LOSS 调整损耗阈值，或设置 LOSS_PROTECTION=false 关闭此功能\n`);
                return true;
            }
            return false;
        } catch (e) {
            console.error('损耗检查异常:', e.message);
            return false;
        }
    }
    async getPositions() {
        if (this.ws && this.ws.positions && this.ws.positions.length > 0) {
            return this.ws.positions.filter(p => parseFloat(p.qty) !== 0);
        }
        const data = await this.api.request('GET', '/api/query_positions', this.token, { symbol: this.symbol });
        return (data || []).filter(p => parseFloat(p.qty) !== 0);
    }
    async getOpenOrders(forceRest = false) {
        if (forceRest || !this.isWsConnected) {
            const data = await this.api.request('GET', '/api/query_open_orders', this.token, { symbol: this.symbol });
            const orders = data?.result || [];
            if (forceRest) {
                this.cachedOpenOrders.clear();
                orders.forEach(o => this.cachedOpenOrders.set(o.id, o));
            }
            return orders;
        }
        if (!this.initialOrderSyncDone) {
            const data = await this.api.request('GET', '/api/query_open_orders', this.token, { symbol: this.symbol });
            const orders = data?.result || [];
            this.cachedOpenOrders.clear();
            orders.forEach(o => this.cachedOpenOrders.set(o.id, o));
            this.initialOrderSyncDone = true;
            console.log(`✅ 初始订单同步: 加载了 ${orders.length} 个订单`);
            return orders;
        }
        return Array.from(this.cachedOpenOrders.values());
    }
    async cancelOrders(orderIds) {
        if (!orderIds || orderIds.length === 0) return;
        try {
            if (this.wsApi && this.wsApi.isAuthenticated && this.wsApi.ws?.readyState === WebSocket.OPEN) {
                try {
                    await Promise.all(orderIds.map(id => this.wsApi.cancelOrder(id)));
                    console.log(`🗑️ 已取消 ${orderIds.length} 个订单 (WS)`);
                    // 立即清除本地缓存
                    this.currentOrderIds = this.currentOrderIds.filter(id => !orderIds.includes(id));
                    this.currentOrders = this.currentOrders.filter(o => !orderIds.includes(o.id));
                    return;
                } catch (e) {
                    // "already canceled" 或 "not open" 都表示订单已不存在，视为成功
                    if (e.message?.includes('already canceled') || e.message?.includes('not open')) {
                        console.log(`🗑️ 订单已撤销 (${orderIds.length}个)`);
                        this.currentOrderIds = this.currentOrderIds.filter(id => !orderIds.includes(id));
                        this.currentOrders = this.currentOrders.filter(o => !orderIds.includes(o.id));
                        return;
                    }
                    console.log(`⚠️ WS 撤单失败: ${e.message}，尝试 REST...`);
                }
            }
            await this.api.request('POST', '/api/cancel_orders', this.token, { order_id_list: orderIds }, this.auth);
            console.log(`🗑️ 已取消 ${orderIds.length} 个订单 (REST)`);
            // 立即清除本地缓存
            this.currentOrderIds = this.currentOrderIds.filter(id => !orderIds.includes(id));
            this.currentOrders = this.currentOrders.filter(o => !orderIds.includes(o.id));
        } catch (e) {
        }
    }
    async updateADX() {
        if (!this.adxEnabled) return;
        if (this.sharedPriceMode && this.currentADX !== null) {
            return;
        }
        const now = Date.now();
        if (now - this.lastADXUpdate < this.adxUpdateInterval) {
            return;
        }
        try {
            const adx = await this.api.getADX(this.symbol, '5m', 14);
            if (adx !== null) {
                this.currentADX = adx;
                this.lastADXUpdate = now;
            }
        } catch (e) {
        }
    }
    async updateRSI() {
        if (this.sharedPriceMode && this.currentRSI !== null) {
            return;
        }
        const now = Date.now();
        if (now - this.lastRSIUpdate < this.rsiUpdateInterval) {
            return;
        }
        try {
            const rsi = await this.api.getRSI(this.symbol, '5m', 14);
            if (rsi !== null) {
                this.currentRSI = rsi;
                this.lastRSIUpdate = now;
            }
        } catch (e) {
        }
    }
    isMarketVolatile() {
        const adxVolatile = this.currentADX !== null && this.currentADX > 40;
        const rsiVolatile = this.currentRSI !== null &&
            (this.currentRSI < this.rsiOversold || this.currentRSI > this.rsiOverbought);
        return adxVolatile || rsiVolatile;
    }
    getADXAdjustedSpread(defaultSpread) {
        if (!this.adxEnabled || this.currentADX === null) {
            return defaultSpread;
        }
        const maxSpread = this.strategyMode === 'aggressive' ? 9.5 : 29;
        if (this.currentADX <= this.adxThreshold) {
            return defaultSpread;
        }
        const effectiveADX = Math.min(this.currentADX, this.adxMax);
        const ratio = (effectiveADX - this.adxThreshold) / (this.adxMax - this.adxThreshold);
        const adjustedSpread = defaultSpread + ratio * (maxSpread - defaultSpread);
        return Math.min(adjustedSpread, maxSpread);
    }
    getEffectiveGridCount(totalBalance) {
        let recommendedCount;
        if (totalBalance < 50) {
            recommendedCount = 1;
        } else if (totalBalance < 500) {
            recommendedCount = 2;  // 2档易监控
        } else {
            recommendedCount = 3;  // 大额最多3档
        }
        return Math.min(this.gridCount, recommendedCount);
    }
    generateGridPrices(markPrice, side) {
        const prices = [];
        const tickSize = this.tickSize || 0.5;
        const adjustedSpreadBps = this.getADXAdjustedSpread(this.spreadBps);
        const modeConfig = this.strategyMode === 'conservative'
            ? STRATEGY_CONFIG.conservative
            : STRATEGY_CONFIG.aggressive;
        const maxAllowedBps = modeConfig.spreadBpsMax || modeConfig.maxBpsDrift;
        const bpsPerTick = (tickSize / markPrice) * 10000;
        const startBps = adjustedSpreadBps;
        for (let i = 0; i < this.gridCount; i++) {
            const currentBps = startBps + (i * bpsPerTick);
            if (currentBps > maxAllowedBps) break;
            const spreadAmount = markPrice * (currentBps / 10000);
            if (side === 'buy') {
                let price = markPrice - spreadAmount;
                price = Math.floor(price / tickSize) * tickSize;
                const actualBps = (markPrice - price) / markPrice * 10000;
                if (actualBps <= maxAllowedBps && actualBps >= startBps - 0.5) {
                    prices.push(price);
                }
            } else {
                let price = markPrice + spreadAmount;
                price = Math.ceil(price / tickSize) * tickSize;
                const actualBps = (price - markPrice) / markPrice * 10000;
                if (actualBps <= maxAllowedBps && actualBps >= startBps - 0.5) {
                    prices.push(price);
                }
            }
        }
        const uniquePrices = [...new Set(prices)];
        if (side === 'buy') {
            uniquePrices.sort((a, b) => b - a);
        } else {
            uniquePrices.sort((a, b) => a - b);
        }
        return uniquePrices;
    }
    calculateOrderDiff(targetPrices, currentOrders, side) {
        const currentPrices = new Set();
        const priceToOrderId = new Map();
        for (const order of currentOrders) {
            if (order.side === side) {
                const price = parseFloat(order.price);
                currentPrices.add(price);
                priceToOrderId.set(price, order.id);
            }
        }
        const targetPriceSet = new Set(targetPrices);
        const toPlace = targetPrices.filter(p => !currentPrices.has(p));
        const toCancel = [];
        for (const [price, orderId] of priceToOrderId) {
            if (!targetPriceSet.has(price)) {
                toCancel.push(orderId);
            }
        }
        return { toPlace, toCancel };
    }
    calculateOptimalStrategy(markPrice, availableBalance) {
        const leverage = this.currentLeverage;
        let qty;
        let marginToUse;
        if (this.fixedOrderQty > 0) {
            qty = this.fixedOrderQty;
            const requiredMargin = (qty * markPrice) / leverage;
            if (requiredMargin > availableBalance) {
                qty = (availableBalance * 0.95 * leverage) / markPrice;
            }
            marginToUse = (qty * markPrice) / leverage;
        } else {
            // 使用95%的传入余额
            marginToUse = availableBalance * 0.95;
            const notionalValue = marginToUse * leverage;
            qty = notionalValue / markPrice;
        }

        // 动态计算最大订单量：基于余额计算，而不是固定值
        // MAX_QTY 环境变量仅作为每档上限（如果设置），不限制总量
        const envMaxQty = parseFloat(process.env.MAX_QTY || '10');  // 默认提高到 10 BTC
        const maxQty = Math.min(
            envMaxQty,
            this.maxOrderQty || 100
        );
        if (qty > maxQty) {
            qty = maxQty;
        }
        const minQty = this.minOrderQty || 0.0001;
        if (qty < minQty) {
            qty = minQty;
        }
        const qtyStep = this.qtyStep || 0.0001;
        qty = Math.floor(qty / qtyStep) * qtyStep;
        const decimals = Math.max(0, -Math.floor(Math.log10(qtyStep)));
        qty = parseFloat(qty.toFixed(decimals));
        const actualNotional = qty * markPrice;
        return {
            leverage: leverage,
            qty: qty,
            notionalValue: actualNotional,
            marginUsed: marginToUse
        };
    }
    shouldRefreshOrders(markPrice) {
        if (!this.smartRefresh || !this.lastMarkPrice) {
            return true;
        }
        const priceChange = Math.abs(markPrice - this.lastMarkPrice) / this.lastMarkPrice;
        if (priceChange > this.priceChangeThreshold) {
            return true;
        }
        if (this.currentOrderIds.length === 0) {
            return true;
        }
        // 检查订单是否超出 bps 有效范围
        const isConservative = this.strategyMode === 'conservative';
        const minBps = isConservative ? 10 : 8;
        const maxBps = isConservative ? 30 : 10;
        for (const order of this.currentOrders || []) {
            const orderPrice = parseFloat(order.price);
            const bps = order.side === 'buy'
                ? (markPrice - orderPrice) / markPrice * 10000
                : (orderPrice - markPrice) / markPrice * 10000;
            if (bps < minBps || bps > maxBps) {
                return true;  // 有订单超出范围，需要刷新
            }
        }
        return false;
    }
    async checkOrdersValidity(markPrice) {
        if (this.currentOrders.length === 0) return false;
        const modeConfig = this.strategyMode === 'conservative'
            ? STRATEGY_CONFIG.conservative
            : STRATEGY_CONFIG.aggressive;
        const maxBpsForStrategy = (modeConfig.spreadBpsMax || modeConfig.maxBpsDrift) - 0.5;
        const minBpsForStrategy = modeConfig.minBpsForRange || 0;
        for (const order of this.currentOrders) {
            const orderPrice = parseFloat(order.price);
            const distanceBps = Math.abs(orderPrice - markPrice) / markPrice * 10000;
            if (distanceBps > maxBpsForStrategy) {
                return false;
            }
            if (distanceBps < minBpsForStrategy + 0.5) {
                console.log(`⚠️ 订单 ${order.side} @ $${orderPrice} 距离仅 ${distanceBps.toFixed(1)} bps，低于区间下限 ${minBpsForStrategy} bps`);
                return false;
            }
            if (minBpsForStrategy === 0 && distanceBps < 3) {
                console.log(`⚠️ 订单 ${order.side} @ $${orderPrice} 距离仅 ${distanceBps.toFixed(1)} bps，成交风险高`);
                return false;
            }
        }
        return true;
    }
    async monitorBuyOrder() {
        if (this.isMonitoringBuy) return;
        this.isMonitoringBuy = true;
        try {
            const buyOrders = this.currentOrders.filter(o => o.side === 'buy');
            if (buyOrders.length === 0) return;
            const markPrice = await this.getCurrentPrice();
            const isHighVol = this.sharedPriceMode ? this.isHighVolatility : this.checkVolatility(markPrice).isHighVolatility;
            if (isHighVol) {
                console.log(`\n⚠️ 检测到高波动，取消买单避免风险`);
                const ids = buyOrders.map(o => o.id);
                await this.cancelOrders(ids);
                return;
            }
            // bps 范围检查已由 _doRefreshGridOrders 统一处理，这里不重复
            // 只保留高波动撤单逻辑
        } catch (e) {
        } finally {
            this.isMonitoringBuy = false;
        }
    }
    async monitorSellOrder() {
        if (this.isMonitoringSell) return;
        this.isMonitoringSell = true;
        try {
            const sellOrders = this.currentOrders.filter(o => o.side === 'sell');
            if (sellOrders.length === 0) return;
            const markPrice = await this.getCurrentPrice();
            const isHighVol = this.sharedPriceMode ? this.isHighVolatility : this.checkVolatility(markPrice).isHighVolatility;
            if (isHighVol) {
                console.log(`\n⚠️ 检测到高波动，取消卖单避免风险`);
                const ids = sellOrders.map(o => o.id);
                await this.cancelOrders(ids);
                return;
            }
            // bps 范围检查已由 _doRefreshGridOrders 统一处理，这里不重复
            // 只保留高波动撤单逻辑
        } catch (e) {
        } finally {
            this.isMonitoringSell = false;
        }
    }
    async quickPositionCheck() {
        if (this.isClosingPosition) return;
        try {
            const positions = await this.getPositions();
            if (positions.length > 0) {
                const pos = positions[0];
                const qty = parseFloat(pos.qty);
                if (qty !== 0) {
                    await this.checkAndClosePositions();
                }
            }
        } catch (e) {
        }
    }
    checkVolatility(currentPrice) {
        const now = Date.now();
        this.priceHistory.push({
            price: currentPrice,
            timestamp: now
        });
        if (this.priceHistory.length > this.maxPriceHistory) {
            this.priceHistory.shift();
        }
        if (this.priceHistory.length < 3) {
            return { isHighVolatility: false, volatilityBps: 0 };
        }
        const recentPrices = this.priceHistory.filter(p => now - p.timestamp < 3000);
        if (recentPrices.length < 2) {
            return { isHighVolatility: false, volatilityBps: 0 };
        }
        const prices = recentPrices.map(p => p.price);
        const maxPrice = Math.max(...prices);
        const minPrice = Math.min(...prices);
        const volatilityBps = (maxPrice - minPrice) / currentPrice * 10000;
        const isHighVolatility = volatilityBps > this.volatilityThreshold;
        if (isHighVolatility && !this.isHighVolatility) {
            this.isHighVolatility = true;
            this.volatilityPauseUntil = now + this.volatilityProtectionDelay;
            const pauseMinutes = Math.floor(this.volatilityProtectionDelay / 60000);
            const pauseSeconds = Math.floor((this.volatilityProtectionDelay % 60000) / 1000);
            console.log(`\n⚠️ 检测到高波动! 价格波动 ${volatilityBps.toFixed(1)} bps (阈值: ${this.volatilityThreshold} bps)`);
            if (pauseMinutes > 0) {
                console.log(`   🛡️ 波动保护: 暂停挂单 ${pauseMinutes} 分钟 ${pauseSeconds} 秒`);
            } else {
                console.log(`   🛡️ 波动保护: 暂停挂单 ${pauseSeconds} 秒`);
            }
            if (this.currentOrderIds.length > 0) {
                console.log(`   🗑️ 取消现有订单以避免风险...`);
                this.cancelOrders(this.currentOrderIds).catch(() => { });
                this.currentOrderIds = [];
                this.currentOrders = [];
            }
        }
        if (!isHighVolatility && this.isHighVolatility && now > this.volatilityPauseUntil) {
            this.isHighVolatility = false;
            console.log(`✅ 波动率降低，恢复正常挂单`);
        }
        return { isHighVolatility, volatilityBps };
    }
    async placeOrder(side, qty, price) {
        if (this.isExiting) {
            return { success: false, error: 'exiting' };
        }
        // 确保价格和数量符合 StandX tick 要求
        price = parseFloat(price).toFixed(2);  // price_tick_decimals: 2
        qty = parseFloat(qty).toFixed(3);      // qty_tick_decimals: 3
        const clOrdId = `${side[0]}${Date.now()}${Math.floor(Math.random() * 1000)}`;
        const orderData = {
            symbol: this.symbol,
            side: side,
            order_type: 'limit',
            price: price,
            qty: qty,
            time_in_force: 'gtc',
            post_only: true,
            reduce_only: false,
            cl_ord_id: clOrdId
        };
        if (this.wsApi && this.wsApi.isAuthenticated && this.wsApi.ws?.readyState === WebSocket.OPEN) {
            try {
                const wsRes = await this.wsApi.placeOrder(orderData);
                return {
                    success: true,
                    id: wsRes.id || (wsRes.data && wsRes.data.id),
                    clOrdId,
                    data: wsRes,
                    side: side,
                    price: price,
                    qty: qty,
                    pending: true
                };
            } catch (e) {
                // 显示所有错误用于调试
                console.log(`⚠️ WS下单失败 [${side}]: ${e.message}`);
            }
        }
        const payload = orderData;
        try {
            const result = await this.api.request('POST', '/api/new_order', this.token, payload, this.auth);
            if (result?.code === 0) {
                return {
                    success: true,
                    id: result.data?.id || result.data?.order_id,
                    requestId: result.request_id,
                    clOrdId: clOrdId,
                    side: side,
                    price: price,
                    qty: qty,
                    pending: true
                };
            }
            const errMsg = result?.message || 'unknown';
            console.log(`   [${side}] REST失败: ${errMsg}`);
            return { success: false, error: errMsg };
        } catch (e) {
            const errMsg = e.response?.data?.message || e.message;
            console.log(`   [${side}] REST异常: ${errMsg}`);
            return { success: false, error: errMsg };
        }
    }
    async verifyOrdersPlaced(expectedOrders) {
        const initialWait = this.isWsConnected ? 100 : 300;
        await new Promise(r => setTimeout(r, initialWait));
        let openOrders = await this.getOpenOrders();
        const results = {
            verified: [],
            rejected: [],
            openOrders: openOrders
        };
        for (const expected of expectedOrders) {
            if (!expected.success) {
                results.rejected.push(expected);
                continue;
            }
            const matchSide = (s1, s2) => (s1 || "").toLowerCase() === (s2 || "").toLowerCase();
            let found = openOrders.find(o =>
                o.cl_ord_id === expected.clOrdId ||
                (expected.id && o.id === expected.id) ||
                (matchSide(o.side, expected.side) && Math.abs(parseFloat(o.price) - expected.price) < 1.0)
            ) || (
                    (expected.clOrdId && this.recentlyFilledOrders.has(expected.clOrdId)) ||
                    (expected.id && this.recentlyFilledOrders.has(expected.id))
                );
            if (!found) {
                const waitTime = this.isWsConnected ? 300 : 500;
                await new Promise(r => setTimeout(r, waitTime));
                openOrders = await this.getOpenOrders(true);
                results.openOrders = openOrders;
                found = openOrders.find(o =>
                    o.cl_ord_id === expected.clOrdId ||
                    (expected.id && o.id === expected.id) ||
                    (o.side === expected.side && Math.abs(parseFloat(o.price) - expected.price) < 0.1)
                ) || (
                        (expected.clOrdId && this.recentlyFilledOrders.has(expected.clOrdId)) ||
                        (expected.id && this.recentlyFilledOrders.has(expected.id))
                    );
            }
            if (found) {
                results.verified.push({
                    ...expected,
                    orderId: (found === true ? (expected.id || expected.clOrdId) : found.id),
                    verified: true
                });
                this.stats.ordersPlaced++;
            } else {
                results.rejected.push({ ...expected, verified: false, reason: 'post_only_rejected' });
                try {
                    const tick = this.tickSize || 0.5;
                    let safePrice = parseFloat(expected.price);
                    expected.side === 'buy' ? safePrice -= tick * 10 : safePrice += tick * 10;
                    safePrice = Math.round(safePrice / tick) * tick;
                    const retryRes = await this.placeOrder(expected.side, expected.qty, safePrice);
                    if (retryRes.success) {
                        await new Promise(r => setTimeout(r, 600));
                        const lastCheckOrders = await this.getOpenOrders();
                        const matchSide = (s1, s2) => (s1 || "").toLowerCase() === (s2 || "").toLowerCase();
                        const retryFound = lastCheckOrders.find(o =>
                            (retryRes.clOrdId && o.cl_ord_id === retryRes.clOrdId) ||
                            (matchSide(o.side, expected.side) && Math.abs(parseFloat(o.price) - safePrice) < tick * 2)
                        ) || (retryRes.clOrdId && this.recentlyFilledOrders.has(retryRes.clOrdId));
                        if (retryFound) {
                            results.verified.push({
                                ...expected,
                                price: safePrice,
                                orderId: (retryFound === true ? retryRes.clOrdId : retryFound.id),
                                verified: true
                            });
                            results.rejected.pop();
                            results.openOrders = lastCheckOrders;
                        }
                    }
                } catch (e) {
                }
            }
        }
        return results;
    }
    async closePosition(qty, side) {
        const closeSide = side === 'long' ? 'sell' : 'buy';
        let remainingQty = Math.abs(qty);

        for (let attempt = 1; attempt <= 5; attempt++) {
            if (remainingQty < 0.0001) {  // 小于最小订单量 0.0001，认为已平完
                console.log(`✅ 持仓已清零`);
                return true;
            }

            try {
                // 使用当前剩余数量（而不是原始数量）
                const qtyToClose = parseFloat(remainingQty.toFixed(3));
                const payload = {
                    symbol: this.symbol,
                    side: closeSide,
                    order_type: 'market',
                    qty: qtyToClose.toString(),
                    time_in_force: 'ioc',
                    reduce_only: true
                };

                await this.api.request('POST', '/api/new_order', this.token, payload, this.auth);
                await new Promise(r => setTimeout(r, 1000));

                // 检查剩余持仓
                const positions = await this.api.request('GET', '/api/query_positions', this.token, { symbol: this.symbol });
                const posData = positions?.find(p => p.symbol === this.symbol);
                remainingQty = posData?.qty ? Math.abs(parseFloat(posData.qty)) : 0;

                if (remainingQty < 0.0001) {
                    this.stats.ordersFilled++;
                    console.log(`✅ 已平仓 ${side} ${Math.abs(qty).toFixed(4)} @ market`);
                    return true;
                }

                if (attempt < 5) {
                    console.log(`   ⚠️ 平仓未完成，剩余 ${remainingQty.toFixed(4)}，等待 2 秒后重试 (${attempt}/5)...`);
                    await new Promise(r => setTimeout(r, 2000));
                }
            } catch (e) {
                const errMsg = e.response?.data?.message || e.message;
                if (attempt < 5) {
                    console.log(`   ⚠️ 平仓请求失败: ${errMsg}，重试 (${attempt}/5)...`);
                    await new Promise(r => setTimeout(r, 2000));
                } else {
                    console.error(`❌ 平仓失败 (已重试5次): ${errMsg}`);
                }
            }
        }
        return false;
    }
    async checkAndClosePositions() {
        if (this.isClosingPosition || this.isCheckingPosition) return;
        // 5秒冷却：避免过于频繁重试
        if (this.lastCloseAttempt && Date.now() - this.lastCloseAttempt < 5000) return;
        this.isCheckingPosition = true;
        try {
            const positions = await this.api.request('GET', '/api/query_positions', this.token, { symbol: this.symbol });
            if (!positions || positions.length === 0) {
                // 没有持仓，正常返回，finally 会重置标志
                return;
            }
            for (const pos of positions) {
                let qty = parseFloat(pos.qty);
                if (qty === 0) continue;
                this.isClosingPosition = true;
                const side = qty > 0 ? 'long' : 'short';
                const upnl = parseFloat(pos.upnl || 0);
                console.log(`\n🚨 持仓检测! ${side.toUpperCase()} ${Math.abs(qty).toFixed(4)} | PnL: $${upnl.toFixed(2)}`);
                if (this.currentOrderIds.length > 0) {
                    console.log(`   🗑️ 取消 ${this.currentOrderIds.length} 个挂单...`);
                    await this.cancelOrders(this.currentOrderIds);
                    this.currentOrderIds = [];
                    this.currentOrders = [];
                }
                let closeSuccess = false;
                for (let closeAttempt = 1; closeAttempt <= 5; closeAttempt++) {
                    if (this.isExiting) break;
                    const closed = await this.closePosition(qty, side);
                    if (closed) {
                        closeSuccess = true;
                        break;
                    }
                    console.log(`   ⚠️ 平仓未完成，等待 2 秒后重试 (${closeAttempt}/5)...`);
                    await new Promise(r => setTimeout(r, 2000));
                    const retryPos = await this.api.request('GET', '/api/query_positions', this.token, { symbol: this.symbol }) || [];
                    const retryQty = retryPos[0]?.qty ? parseFloat(retryPos[0].qty) : 0;
                    if (Math.abs(retryQty) < 0.0001) {
                        closeSuccess = true;
                        console.log(`   ✅ 持仓已清空`);
                        break;
                    }
                    qty = retryQty;
                }
                if (!closeSuccess) {
                    console.log(`   ⚠️ 平仓失败，5秒后重试。继续正常交易...`);
                    this.lastCloseAttempt = Date.now();  // 记录时间，5秒内不再尝试
                    this.isClosingPosition = false;  // 允许继续交易
                    return;
                }
                this.stats.totalPnl += upnl;
                this.consecutiveFills++;
                // 取消成交后自动切换保守模式 - 保持激进模式
                // if (!this.isConservativeMode) {
                //     console.log(`\n⚠️ 成交检测，自动切换到保守模式 (20 bps)...`);
                //     this.isConservativeMode = true;
                //     this.spreadBps = 20;
                //     this.conservativeModeUntil = Date.now() + 5 * 60 * 1000;
                // }
                if (this.isExiting) {
                    this.isClosingPosition = false;
                    return;
                }

                // 撤销全部订单
                console.log(`   🗑️ 撤销全部订单...`);
                try {
                    const allOrders = await this.getOpenOrders(true);
                    if (allOrders.length > 0) {
                        await this.cancelOrders(allOrders.map(o => o.id));
                        this.currentOrderIds = [];
                        this.currentOrders = [];
                    }
                } catch (e) {
                    console.log(`   撤单异常: ${e.message}`);
                }

                // 冷却5分钟
                console.log(`   ⏸️ 冷却 5 分钟后重新挂单...`);
                this.pauseUntil = Date.now() + 5 * 60 * 1000;  // 5分钟
                await new Promise(r => setTimeout(r, 5 * 60 * 1000));
                if (!this.isExiting) {
                    await this.refreshOrders();
                }
            }
        } catch (e) {
            console.error('检查持仓异常:', e.message);
        } finally {
            this.isClosingPosition = false;
            this.isCheckingPosition = false;
        }
    }
    async refreshGridOrders(markPrice, balance) {
        if (this.isExiting) return;
        if (this._isRefreshingGrid) {
            return;
        }
        this._isRefreshingGrid = true;
        try {
            await this._doRefreshGridOrders(markPrice, balance);
        } finally {
            this._isRefreshingGrid = false;
        }
    }
    async _doRefreshGridOrders(markPrice, balance) {
        if (this.isExiting) return;
        if (this.pauseUntil && Date.now() < this.pauseUntil) {
            return;
        }
        if (!balance) {
            try {
                balance = await this.getBalance();
            } catch (e) {
                console.log(`⚠️ 获取余额失败: ${e.message}，跳过本次刷新`);
                return;
            }
        }
        const totalBalance = balance.balance;
        const effectiveGridCount = this.getEffectiveGridCount(totalBalance);
        if (this._lastEffectiveGridCount !== undefined && effectiveGridCount !== this._lastEffectiveGridCount) {
            console.log(`   📊 余额变化 $${totalBalance.toFixed(0)} → 调整为 ${effectiveGridCount} 档 (原${this._lastEffectiveGridCount}档)`);
        } else if (effectiveGridCount !== this.gridCount && this._lastEffectiveGridCount === undefined) {
            console.log(`   📊 余额 $${totalBalance.toFixed(0)} → 自动调整为 ${effectiveGridCount} 档`);
        }
        this._lastEffectiveGridCount = effectiveGridCount;

        // 使用【总余额】计算订单大小，确保所有订单大小一致
        // 按6单（3买+3卖）平均分配总余额
        const totalOrderCount = effectiveGridCount * 2;
        const marginPerOrder = (totalBalance * 0.85) / totalOrderCount;  // 85%利用率，留15%缓冲
        const notionalPerOrder = marginPerOrder * this.currentLeverage;
        let qtyPerOrder = notionalPerOrder / markPrice;
        const stepSize = this.stepSize || 0.0001;
        qtyPerOrder = Math.floor(qtyPerOrder / stepSize) * stepSize;
        const decimals = stepSize.toString().split('.')[1]?.length || 0;
        qtyPerOrder = parseFloat(qtyPerOrder.toFixed(decimals));
        const targetOrderCount = effectiveGridCount * 2;
        const targetNotional = qtyPerOrder * markPrice * targetOrderCount;
        const currentOrders = await this.getOpenOrders();
        const currentOrderCount = currentOrders.length;
        let needRefreshAll = false;

        // 不再比较订单数量，因为可用余额会随着订单占用保证金而波动
        // 只要订单存在且在合理价格区间内，就不需要重新下单
        // 这样可以避免频繁撤单重下的问题
        // 如果已有订单且不需要刷新，即使计算出的qtyPerOrder很小也不要报警
        // 因为那只是余额被占用后的计算结果，不代表需要改变现有订单
        if (qtyPerOrder < (this.minOrderQty || 0.0001)) {
            if (currentOrders.length === 0) {
                console.log(`⚠️ 每档数量太小，跳过 (qty=${qtyPerOrder}, bal=$${totalBalance.toFixed(2)}, grid=${effectiveGridCount})`);
            }
            // 已有订单时静默跳过，不打印警告
            return;
        }
        if (needRefreshAll && currentOrders.length > 0) {
            console.log(`   🔄 数量变化大，重新下单以最大化积分...`);
            await this.cancelOrders(currentOrders.map(o => o.id));
            this.currentOrderIds = [];
            this.currentOrders = [];
            await new Promise(r => setTimeout(r, 300));
        }
        const tick = this.tickSize || 0.5;
        const modeConfig = this.strategyMode === 'conservative'
            ? STRATEGY_CONFIG.conservative
            : STRATEGY_CONFIG.aggressive;
        const minBps = this.spreadBps || modeConfig.spreadBps;
        const maxBps = this.spreadBpsMax || modeConfig.spreadBpsMax || modeConfig.maxBpsDrift;
        // 直接使用 spreadBps 计算买卖价格，确保在有效区间内
        const spreadDistance = markPrice * this.spreadBps / 10000;  // 9 bps = ~$86
        const priceUpperLimit = markPrice * 1.01;
        const priceLowerLimit = markPrice * 0.99;

        // 直接计算精确价格，只舍入到 0.01（price_tick）
        // 买单向上舍入（更接近mark），卖单向下舍入（更接近mark）
        // 确保距离不超过目标 spreadBps
        const bidPrice = markPrice - spreadDistance;
        const askPrice = markPrice + spreadDistance;

        // 买单向上舍入（距离变小，确保在目标范围内）
        // 卖单向下舍入（距离变小，确保在目标范围内）
        let bidBase = Math.ceil(bidPrice * 100) / 100;   // 向上舍入到0.01
        let askBase = Math.floor(askPrice * 100) / 100;  // 向下舍入到0.01
        let targetBuyPrices = [];
        // 网格间距：固定 $1 价格间隔
        const gridSpacing = 1;  // 每档间隔 $1
        const orderTolerance = 10;  // 订单匹配容差 $10，避免价格微移就撤单
        for (let i = 0; i < effectiveGridCount; i++) {
            let price = bidBase - i * gridSpacing;
            price = Math.floor(price * 100) / 100;  // 向下舍入到0.01
            if (price >= priceLowerLimit) {
                targetBuyPrices.push(price);
            }
        }
        targetBuyPrices.sort((a, b) => b - a);
        let targetSellPrices = [];
        for (let i = 0; i < effectiveGridCount; i++) {
            let price = askBase + i * gridSpacing;
            price = Math.ceil(price * 100) / 100;  // 向上舍入到0.01
            if (price <= priceUpperLimit) {
                targetSellPrices.push(price);
            }
        }
        targetSellPrices.sort((a, b) => a - b);
        const currentBuyOrders = currentOrders.filter(o => o.side === 'buy');
        const currentSellOrders = currentOrders.filter(o => o.side === 'sell');

        // 根据策略模式设置有效 bps 范围
        // 100%积分(aggressive): 开单9bps, 保持8-10
        // 50%积分(conservative): 开单20bps, 保持10-30
        let validMinBps, validMaxBps;
        if (this.strategyMode === 'aggressive') {
            validMinBps = 8;
            validMaxBps = 10;
        } else {
            // conservative 保守模式
            validMinBps = 10;
            validMaxBps = 30;
        }
        const isInValidRange = (orderPrice, side) => {
            const distBps = side === 'buy'
                ? (markPrice - orderPrice) / markPrice * 10000
                : (orderPrice - markPrice) / markPrice * 10000;
            return distBps >= validMinBps && distBps <= validMaxBps;
        };

        // 只撤销不在有效 bps 范围内的订单（aggressive: 8-10, conservative: 10-30）
        const cancelBuyOrders = currentBuyOrders.filter(o => !isInValidRange(parseFloat(o.price), 'buy'));
        const cancelSellOrders = currentSellOrders.filter(o => !isInValidRange(parseFloat(o.price), 'sell'));

        // 只在本边订单不足时补单
        const toPlaceBuy = currentBuyOrders.length - cancelBuyOrders.length < effectiveGridCount
            ? targetBuyPrices.slice(0, effectiveGridCount - (currentBuyOrders.length - cancelBuyOrders.length))
            : [];
        const toPlaceSell = currentSellOrders.length - cancelSellOrders.length < effectiveGridCount
            ? targetSellPrices.slice(0, effectiveGridCount - (currentSellOrders.length - cancelSellOrders.length))
            : [];

        // 调试：当没有订单时显示原因
        if (currentOrders.length === 0 && toPlaceBuy.length === 0 && toPlaceSell.length === 0) {
            console.log(`   ⚠️ 无订单且无法补单: targetBuy=${targetBuyPrices.length} targetSell=${targetSellPrices.length} grid=${effectiveGridCount}`);
        }
        const toCancelIds = [];
        const cancelReasons = [];
        for (const order of cancelBuyOrders) {
            const orderPrice = parseFloat(order.price);
            const distBps = ((markPrice - orderPrice) / markPrice * 10000).toFixed(1);
            toCancelIds.push(order.id);
            cancelReasons.push(`买$${orderPrice.toFixed(0)}(${distBps}bps)`);
        }
        for (const order of cancelSellOrders) {
            const orderPrice = parseFloat(order.price);
            const distBps = ((orderPrice - markPrice) / markPrice * 10000).toFixed(1);
            toCancelIds.push(order.id);
            cancelReasons.push(`卖$${orderPrice.toFixed(0)}(${distBps}bps)`);
        }
        for (const order of currentOrders) {
            if (!toCancelIds.includes(order.id) && parseFloat(order.qty) < qtyPerOrder * 0.1) {
                toCancelIds.push(order.id);
                cancelReasons.push(`${order.side}数量太小`);
            }
        }
        if (toCancelIds.length > 0) {
            console.log(`   🗑️ 撤销: ${cancelReasons.join(', ')}`);
            await this.cancelOrders(toCancelIds);
            if (this.isExiting) return;
            // 撤单后必须重新获取余额，因为保证金已释放
            try {
                // 等待让资金结算（增加到500ms确保完全释放）
                await new Promise(r => setTimeout(r, 500));
                balance = await this.getBalance();
                console.log(`   🔄 撤单后更新余额: 可用 $${balance.available.toFixed(2)}`);
            } catch (e) {
                console.log(`   ⚠️ 更新余额失败: ${e.message}`);
            }
        }

        const finalKeptBuyCount = currentBuyOrders.filter(o => !toCancelIds.includes(o.id)).length;
        const finalKeptSellCount = currentSellOrders.filter(o => !toCancelIds.includes(o.id)).length;

        // 不再重新计算 qtyPerOrder，直接使用上面基于总余额计算的值
        // 确保数量符合 StandX qty_tick 要求（0.001 的倍数）
        const qtyStep = 0.001;  // StandX BTC-USD qty_tick_decimals: 3
        qtyPerOrder = Math.floor(qtyPerOrder / qtyStep) * qtyStep;
        qtyPerOrder = parseFloat(qtyPerOrder.toFixed(3));  // 保留3位小数

        // 如果舍入后数量太小，使用最小订单量
        if (qtyPerOrder < 0.001) {
            qtyPerOrder = 0.001;
        }

        // 订单大小基于总余额计算，撤单后保证金会释放
        // 不再限制订单数量，让交易所自动拒绝余额不足的订单

        // 不再强制买卖数量一致，允许分别补单

        const placedResults = [];
        // 顺序下单，避免并行竞争余额
        for (const price of toPlaceBuy) {
            if (this.isExiting) break;
            const res = await this.placeOrder('buy', qtyPerOrder, price);
            placedResults.push({ ...res, side: 'buy', price, qty: qtyPerOrder });
        }
        for (const price of toPlaceSell) {
            if (this.isExiting) break;
            const res = await this.placeOrder('sell', qtyPerOrder, price);
            placedResults.push({ ...res, side: 'sell', price, qty: qtyPerOrder });
        }
        const successCount = placedResults.filter(r => r.success).length;
        const failedResults = placedResults.filter(r => !r.success);
        if (failedResults.length > 0) {
            const balanceErrors = failedResults.filter(r => r.error && r.error.toLowerCase().includes('balance')).length;
            const otherErrors = failedResults.length - balanceErrors;
            if (balanceErrors > 0) {
                console.log(`   ⚠️ ${balanceErrors} 单因余额不足失败`);
            }
            if (otherErrors > 0) {
                console.log(`   ⚠️ ${otherErrors} 单因其他原因失败`);
            }
        }
        if (placedResults.length > 0) {
            await this.verifyOrdersPlaced(placedResults);
        }
        const newOrders = await this.getOpenOrders();
        this.currentOrders = newOrders;
        this.currentOrderIds = newOrders.map(o => o.id);
        const buyOrders = newOrders.filter(o => o.side === 'buy');
        const sellOrders = newOrders.filter(o => o.side === 'sell');
        this.updateUptimeStats(buyOrders, sellOrders, markPrice);
        if (!this.isExiting) {
            const placedCount = placedResults.filter(r => r.success).length;
            const cancelCount = toCancelIds.length;
            if (cancelCount > 0 || placedCount > 0) {
                const mh = this.getCurrentHourMakerHours();
                const tierIcon = mh.tier === 'boosted' ? '🟢' : (mh.tier === 'standard' ? '🟡' : '⚪');

                // 计算实时订单距离
                let buyBps = 0, sellBps = 0;
                if (buyOrders.length > 0) {
                    const avgBuyPrice = buyOrders.reduce((s, o) => s + parseFloat(o.price), 0) / buyOrders.length;
                    buyBps = ((markPrice - avgBuyPrice) / markPrice * 10000).toFixed(1);
                }
                if (sellOrders.length > 0) {
                    const avgSellPrice = sellOrders.reduce((s, o) => s + parseFloat(o.price), 0) / sellOrders.length;
                    sellBps = ((avgSellPrice - markPrice) / markPrice * 10000).toFixed(1);
                }

                console.log(`   ✅ 买${buyOrders.length}(${buyBps}bps) 卖${sellOrders.length}(${sellBps}bps) | -${cancelCount} +${placedCount} | ${tierIcon} MH: ${mh.makerHours.toFixed(3)}`);
            }
        }
        if (toCancelIds.length === 0 && toPlaceBuy.length === 0 && toPlaceSell.length === 0) {
            this.dynamicRefreshInterval = Math.min(this.dynamicRefreshInterval + 5000, this.maxRefreshInterval);
        } else {
            this.dynamicRefreshInterval = this.minRefreshInterval;
        }
        await this.quickPositionCheck();
    }
    async refreshOrders() {
        if (this.isExiting) return;
        if (this.pauseUntil && Date.now() < this.pauseUntil) return;
        if (this.isRefreshing || this.isClosingPosition || this.isSupplementing) return;
        this.isRefreshing = true;
        try {
            await this.ensureValidToken();
            const priceData = await this.api.getPrice(this.symbol);
            const markPrice = parseFloat(priceData.mark_price);
            const balance = await this.getBalance();
            this.markSuccessfulOperation();
            const now = Date.now();
            if (this.stats.estimatedPoints > 0) {
                const timeDelta = (now - this.stats.lastUpdateTime) / 1000 / 86400;
                this.stats.totalNotionalTime += this.stats.estimatedPoints * timeDelta;
            }
            this.stats.lastUpdateTime = now;
            const currentBalance = balance.balance;
            if (this.stats.initialBalance !== null) {
                if (currentBalance > this.stats.highestBalance) {
                    this.stats.highestBalance = currentBalance;
                }
                if (currentBalance < this.stats.lowestBalance) {
                    this.stats.lowestBalance = currentBalance;
                }
            }
            const balanceChange = this.stats.initialBalance !== null
                ? currentBalance - this.stats.initialBalance
                : 0;
            this.stats.lastBalance = currentBalance;
            let pnlStr = '';
            if (this.stats.initialBalance !== null) {
                const changeSign = balanceChange >= 0 ? '+' : '';
                const changeIcon = balanceChange >= 0 ? '🟢' : '🔴';
                pnlStr = ` | ${changeIcon}${changeSign}$${balanceChange.toFixed(2)}`;
            }
            console.log(`\n${'='.repeat(60)}`);
            console.log(`📊 Mark: $${markPrice.toFixed(2)} | 可用: $${balance.available.toFixed(2)}${pnlStr}`);
            if (this.smartRefresh && this.currentOrderIds.length > 0) {
                const ordersValid = await this.checkOrdersValidity(markPrice);
                if (ordersValid && !this.shouldRefreshOrders(markPrice)) {
                    console.log(`✅ 订单仍在有效范围内，跳过刷新`);
                    this.markSuccessfulOperation();
                    return;
                }
            }
            if (balance.available < this.minAvailableBalance) {
                console.log(`⚠️ 可用余额不足 $${this.minAvailableBalance}，检查持仓...`);
                await this.checkAndClosePositions();
                return;
            }
            await this.updateRSI();
            await this.updateADX();
            if (this.gridEnabled) {
                await this.refreshGridOrders(markPrice, balance);
                return;
            }

            // === 关键修改：使用【可用余额】而非总权益 ===
            const balancePerSide = (balance.available * this.marginRatio) / 2;
            const optimal = this.calculateOptimalStrategy(markPrice, balancePerSide);
            console.log(`\n🧮 策略:`);
            console.log(`   杠杆: ${this.currentLeverage}x | 数量: ${optimal.qty} BTC`);
            console.log(`   名义价值: $${optimal.notionalValue.toFixed(2)} | 日积分: ~${(optimal.notionalValue * 2).toFixed(0)}`);
            if (optimal.qty < 0.0001) {
                console.log('⚠️ 计算数量太小，跳过');
                return;
            }
            const baseBps = this.getADXAdjustedSpread(this.spreadBps);
            const bidSpreadBps = baseBps + this.buySpreadAdjust;
            const askSpreadBps = baseBps + this.sellSpreadAdjust;
            if (this.adxEnabled && this.currentADX !== null) {
                const adxIcon = this.currentADX > this.adxThreshold ? '📈' : '📊';
                console.log(`   ${adxIcon} ADX(5m): ${this.currentADX.toFixed(1)} | 调整距离: ${baseBps.toFixed(1)} bps`);
            }
            let bidPrice = markPrice * (1 - bidSpreadBps / 10000);
            let askPrice = markPrice * (1 + askSpreadBps / 10000);
            const tick = this.tickSize || 0.5;
            let bidSnapped = Math.floor(bidPrice / tick) * tick;
            let askSnapped = Math.ceil(askPrice / tick) * tick;
            let bidBps = (markPrice - bidSnapped) / markPrice * 10000;
            let askBps = (askSnapped - markPrice) / markPrice * 10000;
            if (bidBps < bidSpreadBps) {
                bidSnapped -= tick;
                bidBps = (markPrice - bidSnapped) / markPrice * 10000;
            }
            if (askBps < askSpreadBps) {
                askSnapped += tick;
                askBps = (askSnapped - markPrice) / markPrice * 10000;
            }
            // 检查保守模式（包括临时切换的）
            const isConservative = this.isConservativeMode || this.strategyMode === 'conservative';
            const maxBps = isConservative ? 29.8 : 9.8;
            if (bidBps > maxBps) {
                bidSnapped = markPrice * (1 - maxBps / 10000);
                bidSnapped = Math.floor(bidSnapped / tick) * tick;
                bidBps = (markPrice - bidSnapped) / markPrice * 10000;
            }
            if (askBps > maxBps) {
                askSnapped = markPrice * (1 + maxBps / 10000);
                askSnapped = Math.ceil(askSnapped / tick) * tick;
                askBps = (askSnapped - markPrice) / markPrice * 10000;
            }
            const buyAdjustInfo = this.buySpreadAdjust > 0 ? ` +${this.buySpreadAdjust.toFixed(1)}` : '';
            const sellAdjustInfo = this.sellSpreadAdjust > 0 ? ` +${this.sellSpreadAdjust.toFixed(1)}` : '';
            let bestBid = null, bestAsk = null;
            if (this.sharedPriceMode && this.sharedDepthBook) {
                bestBid = this.sharedDepthBook.bestBid;
                bestAsk = this.sharedDepthBook.bestAsk;
            } else {
                try {
                    const depth = await this.api.getDepthBook(this.symbol);
                    if (depth.bids && depth.bids.length > 0) {
                        bestBid = parseFloat(depth.bids[0][0]);
                    }
                    if (depth.asks && depth.asks.length > 0) {
                        bestAsk = parseFloat(depth.asks[0][0]);
                    }
                } catch (e) {
                }
            }
            if (bestBid !== null && bidSnapped >= bestBid - tick) {
                bidSnapped = bestBid - tick * 2;
                bidBps = (markPrice - bidSnapped) / markPrice * 10000;
                console.log(`   ⚠️ 买单价格调整为 $${bidSnapped.toFixed(1)} (避免post_only拒绝)`);
            }
            if (bestAsk !== null && askSnapped <= bestAsk + tick * 3) {
                askSnapped = bestAsk + tick * 4;
                askBps = (askSnapped - markPrice) / markPrice * 10000;
                console.log(`   ⚠️ 卖单价格调整为 $${askSnapped.toFixed(1)} (避免post_only拒绝)`);
            }
            const priceTolerance = tick * 2;
            const currentBuyOrder = this.currentOrders.find(o => o.side === 'buy');
            const currentSellOrder = this.currentOrders.find(o => o.side === 'sell');
            let needPlaceBuy = true;
            let needPlaceSell = true;
            let ordersToCancel = [];
            if (currentBuyOrder) {
                const currentBuyPrice = parseFloat(currentBuyOrder.price);
                if (Math.abs(currentBuyPrice - bidSnapped) <= priceTolerance) {
                    needPlaceBuy = false;
                    console.log(`   ✅ 买单保留 $${currentBuyPrice.toFixed(1)}`);
                } else {
                    ordersToCancel.push(currentBuyOrder.id);
                }
            }
            if (currentSellOrder) {
                const currentSellPrice = parseFloat(currentSellOrder.price);
                if (Math.abs(currentSellPrice - askSnapped) <= priceTolerance) {
                    needPlaceSell = false;
                    console.log(`   ✅ 卖单保留 $${currentSellPrice.toFixed(1)}`);
                } else {
                    ordersToCancel.push(currentSellOrder.id);
                }
            }
            if (!needPlaceBuy && !needPlaceSell) {
                console.log(`   ✅ 订单无需调整`);
                return;
            }
            if (ordersToCancel.length > 0) {
                console.log(`   🗑️ 撤销 ${ordersToCancel.length} 个订单`);
                await this.cancelOrders(ordersToCancel);
                this.currentOrderIds = this.currentOrderIds.filter(id => !ordersToCancel.includes(id));
                this.currentOrders = this.currentOrders.filter(o => !ordersToCancel.includes(o.id));
                await new Promise(r => setTimeout(r, 300));
            }
            let buyResult = { success: false };
            let sellResult = { success: false };
            if (needPlaceBuy) {
                console.log(`📈 买单: $${bidSnapped.toFixed(1)} (${bidBps.toFixed(1)} bps)${buyAdjustInfo}`);
                buyResult = await this.placeOrder('buy', optimal.qty, bidSnapped);
                const buySubmit = buyResult.success ? '提交✓' : '提交✗';
                console.log(`   买单${buySubmit}`);
            }
            if (needPlaceSell) {
                if (needPlaceBuy) {
                    await new Promise(r => setTimeout(r, 1000));
                    const newPriceData = await this.api.getPrice(this.symbol);
                    const newMarkPrice = parseFloat(newPriceData.mark_price);
                    askPrice = newMarkPrice * (1 + askSpreadBps / 10000);
                    askSnapped = Math.ceil(askPrice / tick) * tick;
                    askBps = (askSnapped - newMarkPrice) / newMarkPrice * 10000;
                    if (askBps < askSpreadBps) {
                        askSnapped += tick;
                        askBps = (askSnapped - newMarkPrice) / newMarkPrice * 10000;
                    }
                }
                console.log(`📉 卖单: $${askSnapped.toFixed(1)} (${askBps.toFixed(1)} bps)${sellAdjustInfo}`);
                sellResult = await this.placeOrder('sell', optimal.qty, askSnapped);
                const sellSubmit = sellResult.success ? '提交✓' : '提交✗';
                console.log(`   卖单${sellSubmit}`);
            }
            const ordersToVerify = [];
            if (needPlaceBuy) ordersToVerify.push(buyResult);
            if (needPlaceSell) ordersToVerify.push(sellResult);
            let verification = { verified: [], rejected: [], openOrders: [] };
            if (ordersToVerify.length > 0) {
                console.log(`   验证中...`);
                verification = await this.verifyOrdersPlaced(ordersToVerify);
            } else {
                verification.openOrders = await this.getOpenOrders();
                verification.verified = verification.openOrders;
            }
            await this.quickPositionCheck();
            const buyVerified = verification.verified.find(o => o.side === 'buy');
            const sellVerified = verification.verified.find(o => o.side === 'sell');
            const buyStatus = buyVerified ? '✓' : '✗';
            const sellStatus = sellVerified ? '✓' : '✗';
            console.log(`   最终: 买${buyStatus} 卖${sellStatus}`);
            this.lastMarkPrice = markPrice;
            const openOrders = verification.openOrders;
            this.currentOrderIds = openOrders.map(o => o.id);
            this.currentOrders = openOrders;
            if (openOrders.length > 0) {
                let totalNotional = 0;
                for (const order of openOrders) {
                    const orderNotional = parseFloat(order.qty) * markPrice;
                    totalNotional += orderNotional;
                }
                this.stats.estimatedPoints = totalNotional;
                console.log(`💰 活跃: ${openOrders.length}单 | 名义价值: $${totalNotional.toFixed(2)}`);
                const hasBuy = verification.verified.some(o => o.side === 'buy');
                const hasSell = verification.verified.some(o => o.side === 'sell');
                if (!hasBuy || !hasSell) {
                    const missingBuy = !hasBuy;
                    const missingSell = !hasSell;
                    const buyRejected = verification.rejected.find(o => o.side === 'buy' && o.reason === 'post_only_rejected');
                    const sellRejected = verification.rejected.find(o => o.side === 'sell' && o.reason === 'post_only_rejected');
                    if (buyRejected || sellRejected) {
                        const rejectedSides = [];
                        if (buyRejected) rejectedSides.push('买单');
                        if (sellRejected) rejectedSides.push('卖单');
                        console.log(`⚠️ ${rejectedSides.join('、')} 被 post_only 拒绝 (价格太激进)`);
                        this.consecutivePostOnlyRejects++;
                        if (buyRejected) {
                            const oldAdjust = this.buySpreadAdjust;
                            this.buySpreadAdjust = Math.min(this.buySpreadAdjust + 0.3, this.maxSpreadAdjust);
                            if (this.buySpreadAdjust !== oldAdjust) {
                                console.log(`   📊 买单距离调整: ${this.spreadBps}+${this.buySpreadAdjust.toFixed(1)} = ${(this.spreadBps + this.buySpreadAdjust).toFixed(1)} bps`);
                            } else {
                                console.log(`   ⚠️ 买单调整已达上限 (${(this.spreadBps + this.buySpreadAdjust).toFixed(1)} bps)，跳过本次`);
                            }
                        }
                        if (sellRejected) {
                            const oldAdjust = this.sellSpreadAdjust;
                            this.sellSpreadAdjust = Math.min(this.sellSpreadAdjust + 0.3, this.maxSpreadAdjust);
                            if (this.sellSpreadAdjust !== oldAdjust) {
                                console.log(`   📊 卖单距离调整: ${this.spreadBps}+${this.sellSpreadAdjust.toFixed(1)} = ${(this.spreadBps + this.sellSpreadAdjust).toFixed(1)} bps`);
                            } else {
                                console.log(`   ⚠️ 卖单调整已达上限 (${(this.spreadBps + this.sellSpreadAdjust).toFixed(1)} bps)，跳过本次`);
                            }
                        }
                        const reachedLimit = (buyRejected && this.buySpreadAdjust >= this.maxSpreadAdjust) ||
                            (sellRejected && this.sellSpreadAdjust >= this.maxSpreadAdjust);
                        if (reachedLimit) {
                            console.log(`   ⏸️ 调整已达上限，暂停补单，等待价格变化...`);
                            return;
                        }
                        console.log(`   ⚡ 只补缺失的一边 (保留成功的订单)...`);
                        setTimeout(async () => {
                            this.isSupplementing = true;
                            try {
                                const priceData = await this.api.getPrice(this.symbol);
                                const newMarkPrice = parseFloat(priceData.mark_price);
                                const balance = await this.getBalance();
                                const optimal = this.calculateOptimalStrategy(newMarkPrice, balance.available);
                                const tick = this.tickSize || 0.5;
                                if (buyRejected && !sellRejected) {
                                    const bidSpreadBps = this.spreadBps + this.buySpreadAdjust;
                                    let bidPrice = newMarkPrice * (1 - bidSpreadBps / 10000);
                                    let bidSnapped = Math.floor(bidPrice / tick) * tick;
                                    let bidBps = (newMarkPrice - bidSnapped) / newMarkPrice * 10000;
                                    if (bidBps < bidSpreadBps) bidSnapped -= tick;
                                    bidBps = (newMarkPrice - bidSnapped) / newMarkPrice * 10000;
                                    console.log(`\n📈 补买单: $${bidSnapped.toFixed(1)} (${bidBps.toFixed(1)} bps)`);
                                    const result = await this.placeOrder('buy', optimal.qty, bidSnapped);
                                    console.log(`   买单提交${result.success ? '✓' : '✗'}`);
                                    if (result.success) {
                                        console.log(`   等待0.5秒验证...`);
                                        await new Promise(r => setTimeout(r, 500));
                                        const verification = await this.verifyOrdersPlaced([result]);
                                        if (verification.verified.length > 0) {
                                            const orders = await this.getOpenOrders();
                                            this.currentOrderIds = orders.map(o => o.id);
                                            this.currentOrders = orders;
                                            if (orders.length === 2) {
                                                console.log(`✅ 补买单成功，双边完整 (共${orders.length}单)`);
                                                this.consecutivePostOnlyRejects = 0;
                                                this.buySpreadAdjust = Math.max(this.buySpreadAdjust - 0.2, 0);
                                            } else {
                                                console.log(`✅ 补买单成功 (当前${orders.length}单)`);
                                            }
                                        } else {
                                            console.log(`⚠️ 补买单被拒绝，等待下次刷新`);
                                        }
                                    }
                                } else if (sellRejected && !buyRejected) {
                                    const askSpreadBps = this.spreadBps + this.sellSpreadAdjust;
                                    let askPrice = newMarkPrice * (1 + askSpreadBps / 10000);
                                    let askSnapped = Math.ceil(askPrice / tick) * tick;
                                    let askBps = (askSnapped - newMarkPrice) / newMarkPrice * 10000;
                                    if (askBps < askSpreadBps) askSnapped += tick;
                                    askBps = (askSnapped - newMarkPrice) / newMarkPrice * 10000;
                                    console.log(`\n📉 补卖单: $${askSnapped.toFixed(1)} (${askBps.toFixed(1)} bps)`);
                                    const result = await this.placeOrder('sell', optimal.qty, askSnapped);
                                    console.log(`   卖单提交${result.success ? '✓' : '✗'}`);
                                    if (result.success) {
                                        console.log(`   等待0.5秒验证...`);
                                        await new Promise(r => setTimeout(r, 500));
                                        const verification = await this.verifyOrdersPlaced([result]);
                                        if (verification.verified.length > 0) {
                                            const orders = await this.getOpenOrders();
                                            this.currentOrderIds = orders.map(o => o.id);
                                            this.currentOrders = orders;
                                            if (orders.length === 2) {
                                                console.log(`✅ 补卖单成功，双边完整 (共${orders.length}单)`);
                                                this.consecutivePostOnlyRejects = 0;
                                                this.sellSpreadAdjust = Math.max(this.sellSpreadAdjust - 0.2, 0);
                                            } else {
                                                console.log(`✅ 补卖单成功 (当前${orders.length}单)`);
                                            }
                                        } else {
                                            console.log(`⚠️ 补卖单被拒绝，等待下次刷新`);
                                        }
                                    }
                                } else {
                                    console.log(`⚠️ 双边都失败，等待正常刷新周期`);
                                }
                            } catch (e) {
                                console.log('补单失败:', e.message);
                            } finally {
                                this.isSupplementing = false;
                            }
                        }, 1000);
                    } else if (buyResult.success && sellResult.success) {
                        console.log(`⚠️ 可能有订单已成交，检查持仓...`);
                        setTimeout(() => this.checkAndClosePositions(), 500);
                    }
                } else {
                    if (this.consecutivePostOnlyRejects > 0) {
                        this.consecutivePostOnlyRejects = 0;
                    }
                    let adjusted = false;
                    if (this.buySpreadAdjust > 0) {
                        this.buySpreadAdjust = Math.max(this.buySpreadAdjust - 0.3, 0);
                        adjusted = true;
                    }
                    if (this.sellSpreadAdjust > 0) {
                        this.sellSpreadAdjust = Math.max(this.sellSpreadAdjust - 0.3, 0);
                        adjusted = true;
                    }
                    if (adjusted && this.buySpreadAdjust === 0 && this.sellSpreadAdjust === 0) {
                        console.log(`   ✅ 挂单距离恢复正常`);
                    }
                }
            } else {
                console.log('⚠️ 无活跃订单，检查持仓...');
                await this.checkAndClosePositions();
            }
        } catch (e) {
            this.consecutiveErrors++;
            console.error(`刷新订单失败 (${this.consecutiveErrors}/${this.maxConsecutiveErrors}): ${e.message}`);
            const isNetworkError = e.message.includes('Proxy') ||
                e.message.includes('ECONNRESET') ||
                e.message.includes('ETIMEDOUT') ||
                e.message.includes('ECONNREFUSED') ||
                e.message.includes('socket hang up') ||
                e.message.includes('connect') ||
                e.message.includes('timeout');
            if (e.response?.status === 401 || e.message.includes('unauthorized') || e.message.includes('expired')) {
                console.log('🔄 认证失效，尝试重新登录...');
                try {
                    await this.refreshToken();
                    console.log('✅ 重新认证成功，立即重试...');
                    this.isRefreshing = false;
                    setTimeout(() => this.refreshOrders(), 1000);
                    return;
                } catch (authErr) {
                    console.error('重新认证失败:', authErr.message);
                }
            }
            if (isNetworkError && this.consecutiveErrors < 5) {
                this.isRefreshing = false;
                setTimeout(() => this.refreshOrders(), 1000);
                return;
            }
            if (this.consecutiveErrors >= this.maxConsecutiveErrors) {
                console.log(`⚠️ 连续 ${this.consecutiveErrors} 次错误，暂停 30 秒...`);
                await new Promise(r => setTimeout(r, 30000));
                this.consecutiveErrors = 0;
            }
        } finally {
            this.isRefreshing = false;
        }
    }
    async run() {
        await this.init();
        const balance = await this.getBalance();
        const priceData = await this.api.getPrice(this.symbol);
        const markPrice = parseFloat(priceData.mark_price);
        this.stats.initialBalance = balance.balance;
        this.stats.highestBalance = balance.balance;
        this.stats.lowestBalance = balance.balance;
        this.stats.lastBalance = balance.balance;
        console.log('\n💵 初始账户状态:');
        console.log(`   💰 总余额: $${balance.balance.toFixed(2)} (起始基准)`);
        console.log(`   可用余额: $${balance.available.toFixed(2)}`);
        console.log(`   BTC 价格: $${markPrice.toFixed(2)}`);
        console.log(`   当前杠杆: ${this.currentLeverage}x`);
        await this.checkAndClosePositions();
        const existingOrders = await this.getOpenOrders();
        if (existingOrders.length > 0) {
            await this.cancelOrders(existingOrders.map(o => o.id));
        }
        if (this.currentLeverage !== this.targetLeverage) {
            console.log('\n🔄 清理完成后再次尝试修改杠杆...');
            await this.changeLeverage(this.targetLeverage);
        }
        console.log('\n🚀 开始刷分 (极速模式)...');
        if (!this.ws.ws) this.ws.connect();
        if (!this.wsApi.ws) this.wsApi.connect();
        console.log('⏳ 等待 WebSocket就绪 (市场流 + 操作流)...');
        try {
            await Promise.all([
                this.ws.waitForReady(20000),
                this.wsApi.waitForReady(20000)
            ]);
            console.log('✅ 所有 WebSocket 频道已就绪');
        } catch (e) {
            console.log(`⚠️ WS等待超时或失败: ${e.message}, 将使用 REST 兜底`);
        }
        await this.refreshOrders();
        let heartbeatCount = 0;
        let lastHeartbeatLog = Date.now();
        const mainLoopTimer = setInterval(() => {
            if (this.isExiting) return;
            heartbeatCount++;
            const now = Date.now();
            if (now - lastHeartbeatLog >= 30000) {
                const runSecs = Math.floor((now - this.stats.startTime) / 1000);
                const runMins = Math.floor(runSecs / 60);
                const secs = runSecs % 60;
                const wsStatus = this.isWsConnected ? '🟢' : '🔴';
                const orderCount = this.currentOrderIds.length;
                console.log(`💓 心跳 #${heartbeatCount} | 运行 ${runMins}m${secs}s | WS${wsStatus} | 订单${orderCount}`);
                lastHeartbeatLog = now;
            }
            const wsReconnectCooldown = 120000; // 2分钟冷却
            // 使用 pong 心跳判断连接健康，而不是数据更新
            const wsPongAge = this.ws ? (now - (this.ws.lastPongTime || now)) : 0;
            const wsApiPongAge = this.wsApi ? (now - (this.wsApi.lastPongTime || now)) : 0;
            const maxPongAge = Math.max(wsPongAge, wsApiPongAge);
            if (!this.isWsConnected && maxPongAge > 90000) { // 90秒无心跳才重连
                if (!this.lastWsReconnectAttempt || Date.now() - this.lastWsReconnectAttempt > wsReconnectCooldown) {
                    console.log(`⚠️ WS 心跳超时 (${Math.floor(maxPongAge / 1000)}s)，强制重新连接...`);
                    this.lastWsReconnectAttempt = Date.now();
                    if (this.ws) {
                        try {
                            if (this.ws.reconnectTimeout) clearTimeout(this.ws.reconnectTimeout);
                            this.ws.cleanup();
                            console.log('🔄 重新连接市场流 WebSocket...');
                            this.ws.connect();
                        } catch (e) {
                            console.error('❌ 市场流 WS 重连失败:', e.message);
                        }
                    }
                    if (this.wsApi) {
                        try {
                            if (this.wsApi.reconnectTimeout) clearTimeout(this.wsApi.reconnectTimeout);
                            this.wsApi.cleanup();
                            console.log('🔄 重新连接操作流 WebSocket...');
                            this.wsApi.connect();
                        } catch (e) {
                            console.error('❌ 操作流 WS 重连失败:', e.message);
                        }
                    }
                    this.lastWsPriceUpdate = Date.now();
                    this.refreshOrders();
                }
            }
            if (this.stats && this.stats.lastBalance) {
            }
        }, 1000);
        const checkTimer = setInterval(() => {
            if (this.isExiting) return;
            this.quickPositionCheck();
        }, 1000);
        this.buyMonitorTimer = null;
        this.sellMonitorTimer = null;
        const orderCheckTimer = setInterval(async () => {
            if (this.isExiting || this.isRefreshing || this.isClosingPosition) return;
            try {
                const orders = await this.getOpenOrders();
                const balance = await this.getBalance();
                const effectiveGridCount = this.getEffectiveGridCount(balance.balance);
                const targetPerSide = this.gridEnabled ? effectiveGridCount : 1;
                const buyOrders = orders.filter(o => o.side === 'buy');
                const sellOrders = orders.filter(o => o.side === 'sell');
                const buyCount = buyOrders.length;
                const sellCount = sellOrders.length;
                const minRequired = Math.max(1, Math.floor(targetPerSide * 0.5));

                // 安全机制：确认真的没有订单才强制触发补单
                const wsOrderCount = this.cachedOpenOrders ? this.cachedOpenOrders.size : 0;
                const localOrderCount = this.currentOrders ? this.currentOrders.length : 0;
                const reallyNoOrders = orders.length === 0 && wsOrderCount === 0 && localOrderCount === 0;
                const isPaused = this.pauseUntil && Date.now() < this.pauseUntil;

                if (reallyNoOrders && !this.isClosingPosition && !this.isRefreshing && !isPaused) {
                    console.log('⚠️ 确认订单数为0，强制触发补单...');
                    this.isRefreshing = false;
                    this.isClosingPosition = false;
                    this.isSupplementing = false;
                    this.pauseUntil = 0;  // 清除暂停状态
                    await this.refreshOrders();
                } else if (orders.length === 0) {
                    // 调试：为什么没有触发补单
                    console.log(`⚠️ 订单0但未补单: ws=${wsOrderCount} local=${localOrderCount} closing=${this.isClosingPosition} refreshing=${this.isRefreshing} paused=${isPaused ? Math.floor((this.pauseUntil - Date.now()) / 1000) + 's' : 'no'}`);
                }
            } catch (e) {
            }
        }, 10000);
        let lossCheckTimer = null;
        if (this.lossProtectionEnabled) {
            lossCheckTimer = setInterval(async () => {
                const shouldStop = await this.checkLossProtection();
                if (shouldStop) {
                    clearInterval(mainLoopTimer);
                    clearInterval(checkTimer);
                    clearInterval(orderCheckTimer);
                    if (lossCheckTimer) clearInterval(lossCheckTimer);
                    if (healthCheckTimer) clearInterval(healthCheckTimer);
                    process.exit(2);
                }
            }, this.lossCheckInterval);
        }
        const healthCheckTimer = setInterval(async () => {
            if (this.isExiting) return;
            await this.healthCheck();
        }, 5000);

        // 每秒监控订单距离，超出范围立即刷新
        const distanceMonitorTimer = setInterval(async () => {
            if (this.isExiting || this.isRefreshing || !this.isWsConnected) return;

            try {
                const markPrice = this.lastWsMarkPrice || await this.getCurrentPrice();
                const orders = this.currentOrders || [];
                if (orders.length === 0) return;

                const buyOrders = orders.filter(o => o.side === 'buy');
                const sellOrders = orders.filter(o => o.side === 'sell');

                // 根据模式设置距离范围（与 _doRefreshGridOrders 保持一致）
                const isConservative = this.strategyMode === 'conservative';
                const minBps = isConservative ? 10 : 8;
                const maxBps = isConservative ? 30 : 10;

                let needRefresh = false;
                // 检查是否有订单超出范围
                for (const order of buyOrders) {
                    const bps = (markPrice - parseFloat(order.price)) / markPrice * 10000;
                    if (bps < minBps || bps > maxBps) {
                        needRefresh = true;
                        break;
                    }
                }
                if (!needRefresh) {
                    for (const order of sellOrders) {
                        const bps = (parseFloat(order.price) - markPrice) / markPrice * 10000;
                        if (bps < minBps || bps > maxBps) {
                            needRefresh = true;
                            break;
                        }
                    }
                }

                // 触发刷新（由 refreshOrders 统一处理撤单和下单）
                if (needRefresh && !this.isRefreshing) {
                    await this.refreshOrders();
                }
            } catch (e) {
                // 静默处理错误
            }
        }, 1000);  // 每秒检查一次

        // 每秒检测持仓，发现立即平仓
        const positionMonitorTimer = setInterval(async () => {
            if (this.isExiting || this.isClosingPosition) return;

            try {
                // 使用 WS 推送的持仓信息，更快响应
                const positions = await this.api.request('GET', '/api/query_positions', this.token, { symbol: this.symbol });
                if (!positions || positions.length === 0) return;

                const pos = positions.find(p => p.symbol === this.symbol);
                if (!pos) return;

                const qty = parseFloat(pos.qty);
                if (qty !== 0) {  // 有任何持仓就平仓
                    console.log(`⚡ 检测到持仓 ${qty > 0 ? 'LONG' : 'SHORT'} ${Math.abs(qty).toFixed(4)}，立即平仓`);
                    await this.checkAndClosePositions();
                }
            } catch (e) {
                // 静默处理
            }
        }, 1000);  // 每秒检查持仓

        const statsTimer = setInterval(async () => {
            const runtime = Math.floor((Date.now() - this.stats.startTime) / 1000 / 60);
            const hours = Math.floor(runtime / 60);
            const mins = runtime % 60;
            const runtimeStr = hours > 0 ? `${hours}h${mins}m` : `${mins}m`;
            try {
                const balance = await this.getBalance();
                this.markSuccessfulOperation();
                const currentBalance = balance.balance;
                const balanceChange = currentBalance - this.stats.initialBalance;
                const changeSign = balanceChange >= 0 ? '+' : '';
                const changeIcon = balanceChange >= 0 ? '🟢' : '🔴';
                if (this.lossProtectionEnabled && balanceChange < 0) {
                    const loss = Math.abs(balanceChange);
                    const lossPercent = (loss / this.maxLoss * 100).toFixed(0);
                    if (loss > this.maxLoss * 0.5) {
                        console.log(`⚠️  损耗警告: $${loss.toFixed(2)} / $${this.maxLoss} (${lossPercent}%)`);
                    }
                }
                const estPoints = this.stats.totalNotionalTime.toFixed(0);
                const mh = this.getCurrentHourMakerHours();
                const tierIcon = mh.tier === 'boosted' ? '🟢' : (mh.tier === 'standard' ? '🟡' : '⚪');
                const tierName = mh.tier === 'boosted' ? 'Boosted' : (mh.tier === 'standard' ? 'Standard' : 'None');
                let orderDistanceInfo = '';
                try {
                    const orders = await this.getOpenOrders();
                    const price = await this.getCurrentPrice();
                    if (orders.length > 0 && price) {
                        const buyOrders = orders.filter(o => o.side === 'buy');
                        const sellOrders = orders.filter(o => o.side === 'sell');
                        let minBuyBps = null, maxBuyBps = null;
                        let minSellBps = null, maxSellBps = null;
                        for (const o of buyOrders) {
                            const bps = (price - parseFloat(o.price)) / price * 10000;
                            if (minBuyBps === null || bps < minBuyBps) minBuyBps = bps;
                            if (maxBuyBps === null || bps > maxBuyBps) maxBuyBps = bps;
                        }
                        for (const o of sellOrders) {
                            const bps = (parseFloat(o.price) - price) / price * 10000;
                            if (minSellBps === null || bps < minSellBps) minSellBps = bps;
                            if (maxSellBps === null || bps > maxSellBps) maxSellBps = bps;
                        }
                        const buyRange = minBuyBps !== null ? `${minBuyBps.toFixed(1)}-${maxBuyBps.toFixed(1)}` : 'N/A';
                        const sellRange = minSellBps !== null ? `${minSellBps.toFixed(1)}-${maxSellBps.toFixed(1)}` : 'N/A';
                        const allInRange = (minBuyBps !== null && maxBuyBps <= 10) && (minSellBps !== null && maxSellBps <= 10);
                        const rangeIcon = allInRange ? '✅' : '⚠️';
                        orderDistanceInfo = `   ${rangeIcon} 订单距离: 买${buyRange}bps | 卖${sellRange}bps | Mark: $${price.toFixed(2)}`;
                    }
                } catch (e) { }
                console.log(`\n${'─'.repeat(60)}`);
                console.log(`📊 定时统计 | 运行: ${runtimeStr} | 杠杆: ${this.currentLeverage}x`);
                console.log(`💰 余额: $${currentBalance.toFixed(2)} | ${changeIcon} 累计盈亏: ${changeSign}$${balanceChange.toFixed(2)}`);
                console.log(`   初始: $${this.stats.initialBalance.toFixed(2)} | 最高: $${this.stats.highestBalance.toFixed(2)} | 最低: $${this.stats.lowestBalance.toFixed(2)}`);
                console.log(`   挂单: ${this.stats.ordersPlaced} | 成交: ${this.stats.ordersFilled} | 累计积分: ~${estPoints}`);
                if (orderDistanceInfo) console.log(orderDistanceInfo);
                console.log(`   ${tierIcon} Maker Hours: ${mh.makerHours.toFixed(3)} (${tierName}) | 达标: ${this.uptimeStats.qualifiedHours}/${this.uptimeStats.totalHours}h`);
                console.log(`${'─'.repeat(60)}`);
            } catch (e) {
            }
        }, 60000);
        this.isExiting = false;
        const gracefulExit = async () => {
            if (this.isExiting) return;
            this.isExiting = true;
            console.log('\n🛑 正在安全退出...');
            clearInterval(mainLoopTimer);
            clearInterval(checkTimer);
            clearInterval(statsTimer);
            clearInterval(orderCheckTimer);
            if (lossCheckTimer) clearInterval(lossCheckTimer);
            if (healthCheckTimer) clearInterval(healthCheckTimer);
            if (this.ws) this.ws.cleanup();
            if (this.wsApi) this.wsApi.cleanup();
            console.log('   等待异步操作完成...');
            await new Promise(r => setTimeout(r, 3000));
            let retryCount = 0;
            const maxRetries = 5;
            while (retryCount < maxRetries) {
                try {
                    console.log('🗑️  正在取消所有挂单 (退出中)...');
                    const orders = await this.getOpenOrders(true);
                    if (orders.length === 0) {
                        console.log('   ✅ 已确认无挂单');
                        break;
                    }
                    console.log(`   找到 ${orders.length} 个挂单，正在撤销...`);
                    try {
                        await this.api.request('POST', '/api/cancel_orders', this.token, {
                            order_id_list: orders.map(o => o.id)
                        }, this.auth);
                        console.log(`🗑️ 已取消 ${orders.length} 个订单 (REST)`);
                    } catch (e) {
                        for (const order of orders) {
                            try {
                                await this.api.request('POST', '/api/cancel_order', this.token, { order_id: order.id }, this.auth);
                            } catch (e2) { }
                        }
                    }
                    await new Promise(r => setTimeout(r, 3000));
                    const remainingOrders = await this.getOpenOrders(true);
                    if (remainingOrders.length === 0) {
                        console.log('   ✅ 确认所有挂单已取消');
                        break;
                    } else {
                        console.log(`   ⚠️  仍有 ${remainingOrders.length} 个挂单，准备重试...`);
                        retryCount++;
                    }
                } catch (e) {
                    console.log(`   ⚠️  取消失败: ${e.message}`);
                    retryCount++;
                    await new Promise(r => setTimeout(r, 1000));
                }
            }
            try {
                const finalOrders = await this.getOpenOrders(true);
                if (finalOrders.length > 0) {
                    console.log(`   ⚠️  最终尝试强制撤销 ${finalOrders.length} 个订单...`);
                    for (const order of finalOrders) {
                        try {
                            await this.api.request('POST', '/api/cancel_order', this.token, { order_id: order.id }, this.auth);
                        } catch (e) { }
                    }
                    await new Promise(r => setTimeout(r, 2000));
                }
            } catch (e) { }
            try {
                console.log('📦 正在检查最终持仓...');
                const positions = await this.api.request('GET', '/api/query_positions', this.token, { symbol: this.symbol });
                if (positions && positions.length > 0) {
                    const pos = positions[0];
                    const qty = parseFloat(pos.qty || 0);
                    if (Math.abs(qty) > 0.0001) {
                        console.log(`   发现剩余持仓: ${qty > 0 ? 'LONG' : 'SHORT'} ${Math.abs(qty).toFixed(4)}`);
                        const closeOrder = {
                            symbol: this.symbol,
                            side: qty > 0 ? 'sell' : 'buy',
                            order_type: 'market',
                            qty: String(Math.abs(qty)),
                            time_in_force: 'ioc',
                            reduce_only: true
                        };
                        await this.api.request('POST', '/api/new_order', this.token, closeOrder, this.auth);
                        console.log('   ✅ 已发送平仓请求');
                        await new Promise(r => setTimeout(r, 3000));
                        const checkPos = await this.api.request('GET', '/api/query_positions', this.token, { symbol: this.symbol });
                        if (checkPos && checkPos.length > 0) {
                            const remainQty = parseFloat(checkPos[0].qty || 0);
                            if (Math.abs(remainQty) > 0.0001) {
                                console.log(`   ⚠️ 仍有持仓 ${Math.abs(remainQty).toFixed(4)}，再次尝试...`);
                                const retryOrder = {
                                    symbol: this.symbol,
                                    side: remainQty > 0 ? 'sell' : 'buy',
                                    order_type: 'market',
                                    qty: String(Math.abs(remainQty)),
                                    time_in_force: 'ioc',
                                    reduce_only: true
                                };
                                await this.api.request('POST', '/api/new_order', this.token, retryOrder, this.auth);
                                await new Promise(r => setTimeout(r, 2000));
                            }
                        }
                    }
                }
            } catch (e) {
                console.log(`   ⚠️  平仓清理异常: ${e.message}`);
            }
            const finalCheck = await this.getOpenOrders(true);
            if (finalCheck.length > 0) {
                console.log(`   ⚠️  最终尝试强制撤销 ${finalCheck.length} 个订单...`);
                await this.cancelOrders(finalCheck.map(o => o.id));
                await new Promise(r => setTimeout(r, 3000));
            }
            console.log('✅ 清理完成');
        };
        let exitHandled = false;
        const doExit = () => {
            if (exitHandled) return;
            exitHandled = true;
            gracefulExit()
                .then(() => {
                    const runtime = Math.floor((Date.now() - this.stats.startTime) / 1000 / 60);
                    const runtimeStr = runtime > 0 ? `${runtime}分钟` : '< 1分钟';
                    let finalBalance = this.stats.lastBalance || 0;
                    const initialBalance = this.stats.initialBalance || finalBalance;
                    const totalChange = finalBalance - initialBalance;
                    const changeSign = totalChange >= 0 ? '+' : '';
                    const changeIcon = totalChange >= 0 ? '🟢' : '🔴';
                    console.log(`\n📊 运行: ${runtimeStr} | ${changeIcon} ${changeSign}$${totalChange.toFixed(2)}`);
                    console.log('👋 已安全退出');
                    process.exit(0);
                })
                .catch(e => {
                    console.log(`清理异常: ${e.message}`);
                    process.exit(1);
                });
        };
        if (process.send) {
            process.on('message', (msg) => {
                if (msg.type === 'exit') {
                    doExit();
                }
            });
        }
        process.on('SIGINT', () => {
            doExit();
        });
        process.on('SIGTERM', () => {
            doExit();
        });
        console.log('\n✅ 机器人运行中 (积分优化模式)');
        console.log(`📋 策略: mark price ±${this.spreadBps} bps 双边挂单`);
        console.log(`📋 积分区间: 0-10 bps = 100% | 10-30 bps = 50% | 30-100 bps = 10%`);
        console.log(`📋 杠杆: ${this.currentLeverage}x`);
        console.log(`📋 数据源: WebSocket 实时推送`);
        console.log('📋 按 Ctrl+C 安全退出\n');
    }
}
async function main() {
    const maxStartupRetries = 10;
    let startupAttempt = 0;
    const strategyConfig = await selectStrategyMode();
    setStrategyEnv(strategyConfig);
    while (startupAttempt < maxStartupRetries) {
        startupAttempt++;
        try {
            const bot = new StandXMakerBot();
            await bot.run();
            break;
        } catch (e) {
            const errMsg = e.message || '';
            const isNetworkError = errMsg.includes('Proxy') ||
                errMsg.includes('ETIMEDOUT') ||
                errMsg.includes('ECONNRESET') ||
                errMsg.includes('ECONNREFUSED') ||
                errMsg.includes('socket') ||
                errMsg.includes('timeout') ||
                errMsg.includes('connect');
            if (isNetworkError && startupAttempt < maxStartupRetries) {
                const delay = Math.min(startupAttempt * 5, 30);
                console.error(`\n❌ 启动失败 (${startupAttempt}/${maxStartupRetries}): ${e.message}`);
                console.log(`⏳ ${delay}秒后重试...\n`);
                await new Promise(r => setTimeout(r, delay * 1000));
            } else {
                console.error('❌ 启动失败:', e.message);
                if (startupAttempt >= maxStartupRetries) {
                    console.error(`\n💀 已达到最大重试次数 (${maxStartupRetries})，程序退出`);
                }
                process.exit(1);
            }
        }
    }
}

// 全局错误处理，防止长时间运行崩溃
process.on('uncaughtException', (err) => {
    console.error('[ERROR] 未捕获异常:', err.message);
    // 不退出程序，继续运行
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('[ERROR] 未处理的 Promise 拒绝:', reason?.message || reason);
    // 不退出程序，继续运行
});

if (require.main === module) main().catch(console.error);
module.exports = { StandXAuth, StandXAPI, StandXMakerBot };
