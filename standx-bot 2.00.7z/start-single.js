/**
 * 单账户启动器 - 由 start-accounts.bat 调用
 * 用法: node start-single.js <行号> <策略模式> <网格开关> <网格数> <点差>
 */

const fs = require('fs');
const path = require('path');

// 解析命令行参数
const args = process.argv.slice(2);
const lineNumber = parseInt(args[0]) || 1;
const strategyMode = args[1] || 'aggressive';
const gridEnabled = args[2] || 'true';
const gridCount = args[3] || '10';
const spreadBps = args[4] || '5';

// 读取 accounts.txt
const accountsFile = path.join(__dirname, 'accounts.txt');
const content = fs.readFileSync(accountsFile, 'utf8');
const lines = content.split('\n')
    .map(l => l.trim())
    .filter(l => l && !l.startsWith('#'));

if (lineNumber > lines.length) {
    console.error(`❌ 账户 ${lineNumber} 不存在`);
    process.exit(1);
}

const line = lines[lineNumber - 1];
const parts = line.split('----');
const privateKey = parts[0]?.trim();
const proxyUrl = parts[1]?.trim() || '';

if (!privateKey) {
    console.error(`❌ 账户 ${lineNumber} 私钥为空`);
    process.exit(1);
}

// 设置环境变量
process.env.PRIVATE_KEY = privateKey;
process.env.PROXY_URL = proxyUrl;
process.env.STRATEGY_MODE = strategyMode;
process.env.GRID_ENABLED = gridEnabled;
process.env.GRID_COUNT = gridCount;
process.env.SPREAD_BPS = spreadBps;

console.log(`🚀 启动账户 ${lineNumber}`);
console.log(`   策略: ${strategyMode === 'aggressive' ? '激进' : '保守'}`);
console.log(`   网格: ${gridEnabled === 'true' ? '开启' : '关闭'} (${gridCount}档)`);
console.log(`   点差: ${spreadBps} bps`);
console.log(`   代理: ${proxyUrl ? '有' : '无'}\n`);

// 启动机器人
const { StandXMakerBot } = require('./standx-bot.js');

async function start() {
    const bot = new StandXMakerBot();
    await bot.run();
}

start().catch(e => {
    console.error('❌ 启动失败:', e.message);
    process.exit(1);
});
