/**
 * StandX 多账号启动器 (独立窗口版)
 * 用法: node 启动器.js
 */

const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const readline = require('readline');

async function main() {
    console.log('\n===========================================================');
    console.log('           StandX 多账号启动器 (独立窗口版)');
    console.log('===========================================================\n');

    // 选择策略
    console.log('选择策略:');
    console.log('1. 网格+激进 [推荐]');
    console.log('2. 网格+保守');
    console.log('3. 单档+激进');
    console.log('4. 单档+保守');
    console.log('');

    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    const choice = await new Promise(resolve => {
        rl.question('请选择 [1-4] (默认:1): ', answer => {
            rl.close();
            resolve(answer.trim() || '1');
        });
    });

    const configs = {
        '1': { SM: 'aggressive', GE: 'true', GC: '10', SB: '5', name: '网格+激进' },
        '2': { SM: 'conservative', GE: 'true', GC: '10', SB: '20', name: '网格+保守' },
        '3': { SM: 'aggressive', GE: 'false', GC: '1', SB: '5', name: '单档+激进' },
        '4': { SM: 'conservative', GE: 'false', GC: '1', SB: '20', name: '单档+保守' }
    };
    const config = configs[choice] || configs['1'];
    console.log(`\n已选择: ${config.name}\n`);

    // 读取账户
    const accountsFile = path.join(__dirname, 'accounts.txt');
    const content = fs.readFileSync(accountsFile, 'utf8');
    const accounts = content.split('\n')
        .map(l => l.trim())
        .filter(l => l && !l.startsWith('#'));

    console.log(`找到 ${accounts.length} 个账户\n`);

    // 为每个账户启动独立窗口
    for (let i = 1; i <= accounts.length; i++) {
        console.log(`启动账户 ${i}...`);

        // Windows: 使用 start 命令打开新窗口
        const { exec } = require('child_process');
        exec(`start "Account${i}" cmd /k node start-single.js ${i} ${config.SM} ${config.GE} ${config.GC} ${config.SB}`, {
            cwd: __dirname
        });

        // 延迟 3 秒
        if (i < accounts.length) {
            await new Promise(r => setTimeout(r, 3000));
        }
    }

    console.log('\n===========================================================');
    console.log('所有账户已在独立窗口启动!');
    console.log('每个窗口可以单独关闭');
    console.log('===========================================================\n');
}

main().catch(console.error);
