/**
 * StandX 多账号启动器
 * 统一选择策略后批量启动单账号程序
 */

const { spawn, fork } = require('child_process');
const fs = require('fs');
const path = require('path');
const readline = require('readline');

// 颜色定义
const colors = {
    reset: '\x1b[0m',
    red: '\x1b[31m',
    green: '\x1b[32m',
    yellow: '\x1b[33m',
    cyan: '\x1b[36m',
    blue: '\x1b[34m',
    magenta: '\x1b[35m'
};

const accountColors = [colors.cyan, colors.green, colors.yellow, colors.magenta, colors.blue];

/**
 * 解析 accounts.txt
 * 格式: 私钥----代理URL
 */
function parseAccountsFile(filePath) {
    if (!fs.existsSync(filePath)) {
        console.error(`${colors.red}❌ 找不到账户文件: ${filePath}${colors.reset}`);
        console.log('请创建 accounts.txt，每行格式: 私钥----代理URL');
        process.exit(1);
    }
    const content = fs.readFileSync(filePath, 'utf8');
    const lines = content.split('\n').filter(line => line.trim() && !line.startsWith('#'));
    return lines.map((line, index) => {
        const parts = line.trim().split('----');
        return { index: index + 1, privateKey: parts[0]?.trim(), proxyUrl: parts[1]?.trim() || '' };
    }).filter(acc => acc.privateKey);
}

function maskProxy(url) {
    if (!url) return '无';
    return url.replace(/\/\/.*:.*@/, '//***:***@').replace(/:(\d+):.*:.*$/, ':$1:***:***');
}

/**
 * 交互式选择策略
 */
async function selectStrategy() {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

    console.log(`${colors.cyan}📊 选择策略模式${colors.reset}\n`);
    console.log(`${colors.green}1️⃣  网格模式 + 激进 (100%积分+Uptime) [推荐]${colors.reset}`);
    console.log(`2️⃣  网格模式 + 保守 (50%积分)`);
    console.log(`3️⃣  单档模式 + 激进`);
    console.log(`4️⃣  单档模式 + 保守\n`);

    return new Promise(resolve => {
        rl.question('请选择 [1-4] (默认: 1): ', answer => {
            rl.close();
            const choice = answer.trim() || '1';
            const configs = {
                '1': { mode: 'aggressive', grid: true, spreadBps: 9, gridCount: 10 },
                '2': { mode: 'conservative', grid: true, spreadBps: 20, gridCount: 10 },
                '3': { mode: 'aggressive', grid: false, spreadBps: 9, gridCount: 1 },
                '4': { mode: 'conservative', grid: false, spreadBps: 20, gridCount: 1 }
            };
            const config = configs[choice] || configs['1'];
            console.log(`\n${colors.green}✅ 已选择: ${config.grid ? '网格' : '单档'}模式 + ${config.mode === 'aggressive' ? '激进' : '保守'}${colors.reset}\n`);
            resolve(config);
        });
    });
}

/**
 * 启动单个账户
 */
function startAccount(account, strategy) {
    const color = accountColors[(account.index - 1) % accountColors.length];
    const prefix = `[账户${account.index}]`;

    const env = {
        ...process.env,
        PRIVATE_KEY: account.privateKey,
        PROXY_URL: account.proxyUrl,
        // 传递策略配置，跳过子进程的交互选择
        STRATEGY_MODE: strategy.mode,
        GRID_ENABLED: strategy.grid ? 'true' : 'false',
        GRID_COUNT: String(strategy.gridCount),
        SPREAD_BPS: String(strategy.spreadBps)
    };

    console.log(`${color}${prefix} 启动中... 代理: ${maskProxy(account.proxyUrl)}${colors.reset}`);

    // 使用 fork 而不是 spawn，支持 IPC 消息通信
    const child = fork('standx-bot.js', [], {
        env,
        stdio: ['pipe', 'pipe', 'pipe', 'ipc'],
        cwd: __dirname,
        silent: true
    });

    child.stdout.on('data', data => {
        data.toString().split('\n').filter(l => l.trim()).forEach(line => {
            console.log(`${color}${prefix} ${line}${colors.reset}`);
        });
    });

    child.stderr.on('data', data => {
        data.toString().split('\n').filter(l => l.trim()).forEach(line => {
            console.log(`${color}${prefix} [ERROR] ${line}${colors.reset}`);
        });
    });

    child.on('exit', code => {
        console.log(`${color}${prefix} 进程退出 (code: ${code})${colors.reset}`);
    });

    return child;
}

async function main() {
    console.log(`\n${colors.cyan}═══════════════════════════════════════════════════════════${colors.reset}`);
    console.log(`${colors.cyan}           StandX 多账号启动器${colors.reset}`);
    console.log(`${colors.cyan}═══════════════════════════════════════════════════════════${colors.reset}\n`);

    // 1. 解析账户
    const accounts = parseAccountsFile(path.join(__dirname, 'accounts.txt'));
    console.log(`📋 找到 ${accounts.length} 个账户\n`);

    // 2. 统一选择策略
    const strategy = await selectStrategy();

    // 3. 启动所有账户
    const children = [];
    for (let i = 0; i < accounts.length; i++) {
        const child = startAccount(accounts[i], strategy);
        children.push(child);
        if (i < accounts.length - 1) {
            console.log(`${colors.cyan}   等待 5 秒后启动下一个...${colors.reset}\n`);
            await new Promise(r => setTimeout(r, 5000));
        }
    }

    console.log(`\n${colors.green}✅ 所有账户已启动！${colors.reset}`);
    console.log(`${colors.cyan}📋 按 Ctrl+C 停止所有账户${colors.reset}\n`);

    // 4. 退出处理
    let isExiting = false;
    process.on('SIGINT', () => {
        if (isExiting) return;
        isExiting = true;
        console.log(`\n${colors.yellow}⏳ 正在停止所有账户（等待撤单完成）...${colors.reset}`);

        // 通过 IPC 消息通知子进程优雅退出
        children.forEach(c => {
            try {
                // 发送 IPC 消息触发 gracefulExit
                if (c.connected) {
                    c.send({ type: 'exit' });
                }
            } catch (e) { }
        });

        // 等待所有子进程退出（最多3分钟）
        let exitCount = 0;
        const checkExit = setInterval(() => {
            const stillRunning = children.filter(c => c.exitCode === null && !c.killed);
            if (stillRunning.length === 0) {
                clearInterval(checkExit);
                console.log(`${colors.green}✅ 所有账户已安全退出${colors.reset}`);
                console.log('\n按任意键退出...');
                process.stdin.setRawMode(true);
                process.stdin.resume();
                process.stdin.once('data', () => process.exit(0));
                return;
            }
            exitCount++;
            // 每10秒显示进度
            if (exitCount % 10 === 0) {
                console.log(`${colors.cyan}   等待中... ${stillRunning.length} 个账户仍在清理 (${exitCount}s)${colors.reset}`);
            }
            if (exitCount > 180) {
                clearInterval(checkExit);
                console.log(`${colors.red}⚠️ 超时，强制退出${colors.reset}`);
                children.forEach(c => { try { c.kill('SIGKILL'); } catch (e) { } });
                console.log('\n按任意键退出...');
                process.stdin.setRawMode(true);
                process.stdin.resume();
                process.stdin.once('data', () => process.exit(1));
                return;
            }
        }, 1000);
    });
}

main().catch(console.error);
